<form id="create-server-form" action="{{ route('create-server') }}" method="POST">
    @csrf
    <div class="mt-4 w-full gap-4 mb-4">
        <div class="p-4 rounded-lg border-input bg-cards bg-opacity-70">
            <h2 class="text-2xl font-semibold mb-4 text-white">Instance Details</h2>
            <div class="flex flex-wrap gap-4">
                <!-- Server Name -->
                <div class="flex-1 min-w-[220px]">
                    <div class="flex">
                        <label for="server-name"
                            class="block bg-black border-global mt-2 whitespace-nowrap justify-center border-input text-sm font-semibold text-white p-4 w-[220px] text-center">
                            <div class="flex items-center">
                                <i class="fa-solid mr-2 bg-create fa-edit"></i> Server Name
                            </div>
                        </label>
                        <input type="text" id="server-name" name="name"
                            class="w-full mt-2 bg-black text-white border-global border-input p-2 bd-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="My Server" required>
                    </div>
                </div>

                <!-- Server Description -->
                <div class="flex-1 min-w-[220px]">
                    <div class="flex">
                        <label for="server-description"
                            class="block bg-black border-global mt-2 whitespace-nowrap justify-center border-input text-sm font-semibold text-white p-4 w-[220px] text-center">
                            <div class="flex items-center">
                                <i class="fa-solid mr-2 bg-create fa-feather"></i> Server Description
                            </div>
                        </label>
                        <input type="text" id="server-description" name="description"
                            class="w-full mt-2 bg-black text-white border-global border-input p-2 bd-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="My very cool Minecraft server!" required>
                    </div>
                </div>
            </div>

            <h2 class="text-2xl font-semibold mb-4 text-white mt-6">Allocate Resources</h2>
            <div class="flex flex-col space-y-4">
                <div class="flex flex-wrap gap-4">
                    <!-- Left Column -->
                    <div class="flex-1 min-w-[220px]">
                        <div class="flex flex-col space-y-4">
                            <div class="flex">
                                <label for="ram"
                                    class="block bg-black border-global mt-2 whitespace-nowrap justify-center border-input text-sm font-semibold text-white p-4 w-[220px] text-center">
                                    <div class="flex items-center">
                                        <i class="fa-solid mr-2 bg-create fa-memory"></i> Allocate Memory
                                    </div>
                                </label>
                                <input type="number" value="1024" id="ram" name="ram"
                                    class="w-full mt-2 bg-black text-white border-global border-input p-2 bd-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    placeholder="1024MB" required>
                            </div>

                            <div class="flex">
                                <label for="cpu"
                                    class="block bg-black border-global mt-2 whitespace-nowrap justify-center border-input text-sm font-semibold text-white p-4 w-[220px] text-center">
                                    <div class="flex items-center">
                                        <i class="fa-solid mr-2 bg-create fa-microchip"></i> Allocate Threads
                                    </div>
                                </label>
                                <input type="number" value="100" id="cpu" name="cpu"
                                    class="w-full mt-2 bg-black text-white border-global border-input p-2 bd-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    placeholder="100%" required>
                            </div>

                            <div class="flex">
                                <label for="disk"
                                    class="block bg-black border-global mt-2 whitespace-nowrap justify-center border-input text-sm font-semibold text-white p-4 w-[220px] text-center">
                                    <div class="flex items-center">
                                        <i class="fa-solid mr-2 bg-create fa-hdd"></i> Allocate Storage
                                    </div>
                                </label>
                                <input type="number" value="1024" id="disk" name="disk"
                                    class="w-full mt-2 bg-black text-white border-global border-input p-2 bd-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    placeholder="1024MB" required>
                            </div>
                        </div>
                    </div>

                    <!-- Right Column -->
                    <div class="flex-1 min-w-[220px]">
                        <div class="flex flex-col space-y-4">
                            <div class="flex">
                                <label for="databases"
                                    class="block bg-black border-global mt-2 whitespace-nowrap justify-center border-input text-sm font-semibold text-white p-4 w-[220px] text-center">
                                    <div class="flex items-center">
                                        <i class="fa-solid mr-2 bg-create fa-database"></i> Databases
                                    </div>
                                </label>
                                <input type="number" value="1" id="databases" name="databases"
                                    class="w-full mt-2 bg-black border-global text-white border-input p-2 bd-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    placeholder="1" required>
                            </div>

                            <div class="flex">
                                <label for="backups"
                                    class="block bg-black border-global mt-2 whitespace-nowrap justify-center border-input text-sm font-semibold text-white p-4 w-[220px] text-center">
                                    <div class="flex items-center">
                                        <i class="fa-solid mr-2 bg-create fa-download"></i> Backups
                                    </div>
                                </label>
                                <input type="number" value="1" id="backups" name="backups"
                                    class="w-full mt-2 bg-black border-global text-white border-input p-2 bd-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    placeholder="1" required>
                            </div>

                            <div class="flex">
                                <label for="ports"
                                    class="block bg-black border-global mt-2 whitespace-nowrap justify-center border-input text-sm font-semibold text-white p-4 w-[220px] text-center">
                                    <div class="flex items-center">
                                        <i class="fa-solid mr-2 bg-create fa-network-wired"></i> Ports
                                    </div>
                                </label>
                                <input type="number" value="1" id="ports" name="ports"
                                    class="w-full mt-2 bg-black border-global text-white border-input p-2 bd-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    placeholder="1" required>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <h2 class="text-2xl font-semibold mb-4 text-white mt-6">Location and image</h2>
            <div class="rounded-xl border-input bg-opacity-70">
                <div class="flex flex-col space-y-4">
                    <!-- Version and Location -->
                    <div class="flex flex-wrap gap-4">
                        <!-- Version -->
                        <div class="flex-1 min-w-[220px]">
                            <div class="flex">
                                <label for="egg"
                                    class="block bg-black border-global mt-2 whitespace-nowrap justify-center border-input text-sm font-semibold text-white p-4 w-[220px] text-center">
                                    <div class="flex items-center">
                                        <i class="fa-solid bg-create mr-2 fa-code-branch"></i> Version
                                    </div>
                                </label>
                                @php
                                    $eggs = \App\Models\Egg::all();
                                @endphp
                                <select id="egg" name="egg_id"
                                    class="w-full mt-2 bg-black border-global text-white border-input p-2 bd-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    required>
                                    <option value="">Select Version</option>
                                    @foreach ($eggs as $egg)
                                        <option value="{{ $egg->egg_id }}" data-nest-id="{{ $egg->nest_id }}">
                                            {{ $egg->name }}
                                        </option>
                                    @endforeach
                                </select>
                                <input type="hidden" id="nest-id" name="nest_id">
                            </div>
                        </div>

                        <!-- Location -->
                        <div class="flex-1 min-w-[220px]">
                            <div class="flex">
                                <label for="location_id"
                                    class="block bg-black border-global mt-2 whitespace-nowrap justify-center border-input text-sm font-semibold text-white p-4 w-[220px] text-center">
                                    <div class="flex items-center">
                                        <i class="fa-solid bg-create mr-2 fa-map-marker-alt"></i> Location
                                    </div>
                                </label>
                                <select id="location_id" name="location_id"
                                    class="w-full mt-2 bg-black border-global text-white border-input p-2 bd-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    required>
                                    <option value="">Select Location</option>
                                    @foreach ($locations as $location)
                                        @php
                                            $isDisabled = Auth::user()->credits < $location->fee;
                                        @endphp
                                        <option value="{{ $location->location_id }}"
                                            {{ $isDisabled ? 'disabled' : '' }}
                                            title="{{ $isDisabled ? 'Insufficient credits' : '' }}">
                                            {{ $location->location_name }} - ${{ $location->fee }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mt-8 space-x-2">
                <button type="submit" class="bg-blue-900 text-white py-3 px-4 rounded-lg hover:bg-blue-700">
                    Create Server
                </button>
            </div>
        </div>
    </div>
</form>
