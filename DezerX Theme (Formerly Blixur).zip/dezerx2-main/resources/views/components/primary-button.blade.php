<button {{ $attributes->merge(['type' => 'submit', 'class' => 'bg-blue-900 w-[100px] p-3 rounded-lg text-white']) }}>
    {{ $slot }}
</button>
