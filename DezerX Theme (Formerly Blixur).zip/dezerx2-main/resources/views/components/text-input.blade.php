@props(['disabled' => false])

<input {{ $disabled ? 'disabled' : '' }} {!! $attributes->merge(['class' => 'bg-black p-3 border border-zinc-800 rounded-lg text-white']) !!}>
