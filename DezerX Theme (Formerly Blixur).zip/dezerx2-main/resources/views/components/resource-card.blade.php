<div class="bg-cards p-4 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 ease-in-out transform hover:-translate-y-1">
    <div class="flex items-center space-x-6">
        <div class="rounded-lg animate-pulse">
            <i class="{{ $icon }} bg-icons text-white text-xl"></i>
        </div>
        <div class="flex-1">
            <h2 class="text-xl font-bold text-gray-900 dark:text-gray-100 mb-1">{{ $title }}</h2>
            <div class="flex items-baseline space-x-1">
                <span class="text-xl font-extrabold text-white">{{ $value }}</span>
                <span class="text-lg font-medium text-gray-300">{{ $unit }}</span>
            </div>
        </div>
    </div>
</div>
