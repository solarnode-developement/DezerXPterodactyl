<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Application')</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://kit.fontawesome.com/9dc3304b92.js" crossorigin="anonymous"></script>
    <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>

    <style>
        body {
            background-color: black;
        }

        .bg-card {
            background-color: #0f0f11;
            border-top: 2px solid #4f46e5;
            border-left: 1px solid #1d1d1d;
            border-right: 1px solid #1d1d1d;
            border-bottom: 1px solid #1d1d1d;
        }

        .bg-card-1 {
            background-color: #0f0f11;
        }
        .border-custom {
            border-color: 1px solid #1d1d1d;
        }


        .border-global {
            border: 1px solid #1d1d1d;
        }
    </style>
</head>

<body class="bg-black flex items-center justify-center h-screen">
    @yield('content')
</body>

</html>
