@extends('layouts.dash')
@php
    $ad = \App\Models\Ad::first();
@endphp
@section('title', 'Fun Stuff')

@section('content')
    <style>
        :root {
            --bg-color-cards: #0c0c0c;
            --border-color-cards: #1d1d1d72;
            --bg-color-url: #171719;
            --border-color-global: #1d1d1d;
            --bg-color-icon: #0f0f11;
            --box-shadow-icon: 0px 0px 4px #000;
            --gradient-start: rgba(0, 0, 0, 1);
            --gradient-end: rgba(255, 0, 0, 1);
            --text-color: white;
            --option-bg-color: #171719;
            --option-text-color: white;
        }

        .bg-cards {
            background-color: var(--bg-color-cards);
            border: 1px solid var(--border-color-cards);
        }

        #color {
            background-color: var(--bg-color-url);
            color: var(--text-color);
        }

        #color .red-option {
            background-color: red;
            color: var(--text-color);
        }

        #color .black-option {
            background-color: black;
            color: var(--text-color);
        }

        #color option {
            background-color: var(--option-bg-color);
            color: var(--option-text-color);
        }

        .redorblue {
            background: var(--gradient-start);
            background: -moz-linear-gradient(159deg, var(--gradient-start) 0%, var(--gradient-end) 100%);
            background: -webkit-linear-gradient(159deg, var(--gradient-start) 0%, var(--gradient-end) 100%);
            background: linear-gradient(159deg, var(--gradient-start) 0%, var(--gradient-end) 100%);
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#000000", endColorstr="#ff0000", GradientType=1);
        }

        .bg-icon {
            background-color: var(--bg-color-icon);
            box-shadow: var(--box-shadow-icon);
            border: 1px solid var(--border-color-global);
        }

        .border-devider {
            border-bottom: 1px solid var(--border-color-global);
        }

        .border-global {
            border: 1px solid var(--border-color-global);
        }

        .bg-url {
            background-color: var(--bg-color-url);
            border: 1px solid var(--border-color-global);
        }

        .w-custom {
            width: fit-content;
        }
    </style>

    <x-sidebar />


    <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div class="container mx-auto p-6 bg-cards text-white rounded shadow-lg">
            <h1 class="text-center text-4xl font-bold mb-8">Russian Roulette</h1>
            @if (session('error'))
                <div class="bg-red-600 p-4 rounded mb-4">
                    <p>{{ session('error') }}</p>
                </div>
            @endif
            @if (session('message'))
                <div class="bg-green-600 p-4 rounded mb-4">
                    <p>{{ session('message') }}</p>
                </div>
            @endif
            <form action="{{ route('russian-roulette.play') }}" method="POST" class="text-left">
                @csrf
                <div class="mb-4">
                    <label for="bet" class="block text-xl mb-2">Bet Amount:</label>
                    <input type="number" id="bet" name="bet" min="50" required
                        class="w-full p-2 rounded border-global bg-black focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>

                <div class="mb-6">
                    <label for="color" class="block text-xl mb-2">Choose a color:</label>
                    <select id="color" name="color" required
                        class="w-full p-2 rounded border-global focus:outline-none focus:ring-2 focus:ring-blue-500 bg-black text-white">
                        <option class="red-option" value="red">Red</option>
                        <option class="black-option" value="black">Black</option>
                    </select>
                </div>
                <button type="submit"
                    class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">Spin
                    the Wheel!</button>
            </form>
        </div>


        <x-footer />


        <script>
            document.getElementById('color').addEventListener('change', function() {
                const selectedOption = this.options[this.selectedIndex];
                this.style.backgroundColor = selectedOption.classList.contains('red-option') ? 'red' : 'black';
            });
        </script>
        <script>
            const sidebarLinks = [{
                    title: 'Overview',
                    icon: 'fa-desktop',
                    url: '{{ route('dashboard') }}',
                    active: false,
                },
                {
                    title: 'Deploy Instance',
                    icon: 'fa-plus',
                    url: 'deploy',
                },
                {
                    title: 'Market Place',
                    icon: 'fa-shop',
                    url: 'shop',
                    hasDivider: true,
                },
                {
                    title: 'Credits',
                    icon: 'fa-coins',
                    url: 'credits',
                    active: false,

                },
                {
                    title: 'Fun',
                    icon: 'fa-gun',
                    url: 'russian-roulette',
                    active: true,

                },
                {
                    title: 'Website',
                    icon: 'fa-globe',
                    url: '{{ $ad->website ?? 'https://dezerx.com' }}',
                },

            ];

            function generateSidebarLinks() {
                const sidebarLinksContainer = document.getElementById('sidebar-links');
                sidebarLinks.forEach(link => {
                    const listItem = document.createElement('li');
                    const activeClass = link.active ? 'bg-url' : '';

                    listItem.innerHTML = `
                <a href="${link.url}" class="flex items-center p-2 text-gray-900 rounded-lg dark:text-white group transform transition-transform hover:scale-105 ${activeClass}">
                    <i class="fa-solid fa-lg text-gray-300 ${link.icon}"></i>
                    <span class="flex-1 ms-3 whitespace-nowrap">${link.title}</span>
                </a>
            `;

                    sidebarLinksContainer.appendChild(listItem);
                    if (link.hasDivider) {
                        const divider = document.createElement('div');
                        divider.classList.add('border-custom');
                        sidebarLinksContainer.appendChild(divider);
                    }
                });
            }

            document.addEventListener('DOMContentLoaded', generateSidebarLinks);
        </script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    @endsection
