@extends('layouts.auth')

@section('title', 'Login')

@section('content')
    <div class="w-full bg-zinc-950 border border-zinc-900 p-8 max-w-md rounded-lg shadow-lg">
        <div class="flex items-center mb-6">
            <h2 class="text-2xl font-semibold text-white">Welcome Back!</h2>
        </div>

        @if (session('status'))
            <div class="mb-4 text-green-400">
                {{ session('status') }}
            </div>
        @endif

        <form method="POST" action="{{ route('login') }}">
            @csrf

            <div class="mb-4">
                <label for="email" class="block text-sm font-medium text-gray-300"><i class="fa-solid fa-envelope"></i> Email</label>
                <input id="email" type="email" name="email" placeholder="anthony@dezerx.com" value="{{ old('email') }}"
                    required autofocus autocomplete="username"
                    class="mt-1 block w-full px-4 py-2 border-global rounded-md bg-black text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                @error('email')
                    <p class="mt-2 text-sm text-red-400">{{ $message }}</p>
                @enderror
            </div>

            <div class="mb-4">
                <label for="password" class="block text-sm font-medium text-gray-300"><i class="fa-solid fa-key"></i> Password</label>
                <input id="password" type="password" placeholder="••••••••••" name="password" required autocomplete="current-password"
                    class="mt-1 block w-full px-4 py-2 border-global rounded-md bg-black text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                @error('password')
                    <p class="mt-2 text-sm text-red-400">{{ $message }}</p>
                @enderror
            </div>

            <div class="mb-4">
                <div class="cf-turnstile" data-sitekey="{{ config('services.turnstile.site_key') }}"></div>
                @error('cf-turnstile-response')
                    <p class="mt-2 text-sm text-red-400">{{ $message }}</p>
                @enderror
            </div>

            <div class="flex items-center justify-between mb-4">
                <a href="{{ route('password.request') }}" class="text-sm text-indigo-500 hover:underline">
                    Forgot your password?
                </a>
            </div>

            <button type="submit"
                class="bg-indigo-600 w-full text-white px-4 py-2 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                Log in
            </button>

            <p class="text-gray-400 mt-6 mb-6 text-center">
                If you don't have an account, you can
                <a href="{{ route('register') }}" class="text-indigo-500 hover:underline">register here</a>.
            </p>

            <div class="relative mt-6 w-full">
                <div class="absolute inset-x-0 top-1/2 transform -translate-y-1/2 text-center">
                    <span class="bg-zinc-950 px-2 text-gray-300">OR</span>
                </div>
                <div class="border-b border-zinc-900 w-full"></div>
            </div>
        </form>

        <div class="mt-6">
            <a href="/auth/discord/redirect"
                class="flex bg-indigo-600 items-center justify-center px-4 py-2 text-base font-medium rounded-md text-white border border-indigo-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 w-full">
                <i class="fa-brands fa-discord mr-2"></i> Login with Discord
            </a>
        </div>
    </div>

    <style>
        .border-global {
            border-color: #a7a7a725;
        }
    </style>

    <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
@endsection
