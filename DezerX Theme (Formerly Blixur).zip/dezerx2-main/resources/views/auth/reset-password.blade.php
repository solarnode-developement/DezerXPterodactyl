@extends('layouts.auth')

@section('title', 'Reset Password')

@section('content')
<div class="w-full bg-zinc-950 border border-zinc-900 p-8 max-w-md rounded-lg shadow-lg">
    <div class="flex items-center mb-6">
        <h2 class="text-2xl font-semibold text-white">Reset Password</h2>
    </div>

    <form method="POST" action="{{ route('password.store') }}">
        @csrf

        <!-- Password Reset Token -->
        <input type="hidden" name="token" value="{{ $request->route('token') }}">

        <!-- Email Address -->
        <div class="mb-4">
            <label for="email" class="block text-sm font-medium text-gray-300">
                <i class="fa-solid fa-envelope"></i> Email
            </label>
            <input id="email" type="email" name="email" value="{{ old('email', $request->email) }}" required autofocus
                class="mt-1 block w-full px-4 py-2 border-global rounded-md bg-black text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="your-email@example.com" />
            @error('email')
                <p class="mt-2 text-sm text-red-400">{{ $message }}</p>
            @enderror
        </div>

        <!-- Password -->
        <div class="mb-4">
            <label for="password" class="block text-sm font-medium text-gray-300">
                <i class="fa-solid fa-lock"></i> Password
            </label>
            <input id="password" type="password" name="password" required
                class="mt-1 block w-full px-4 py-2 border-global rounded-md bg-black text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="New Password" />
            @error('password')
                <p class="mt-2 text-sm text-red-400">{{ $message }}</p>
            @enderror
        </div>

        <!-- Confirm Password -->
        <div class="mb-4">
            <label for="password_confirmation" class="block text-sm font-medium text-gray-300">
                <i class="fa-solid fa-lock"></i> Confirm Password
            </label>
            <input id="password_confirmation" type="password" name="password_confirmation" required
                class="mt-1 block w-full px-4 py-2 border-global rounded-md bg-black text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="Confirm New Password" />
            @error('password_confirmation')
                <p class="mt-2 text-sm text-red-400">{{ $message }}</p>
            @enderror
        </div>

        <div class="flex items-center justify-between mt-6">
            <a href="{{ route('login') }}" class="text-sm text-indigo-500 hover:underline">
                Go back to login
            </a>

            <button type="submit"
                class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150 ease-in-out">
                {{ __('Reset Password') }}
            </button>
        </div>
    </form>
</div>
@endsection
