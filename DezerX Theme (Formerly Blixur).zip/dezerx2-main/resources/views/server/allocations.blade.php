@extends('server.layouts.app')

@section('title', 'Network')

@section('content')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
    .console-container {
        background: rgb(13, 22, 33);
        background: -moz-linear-gradient(328deg, rgba(13, 22, 33, 1) 71%, rgba(21, 29, 77, 0.4654236694677871) 100%, rgba(30, 38, 131, 0.5970763305322129) 100%, rgba(18, 19, 19, 1) 100%, rgba(6, 122, 150, 1) 100%, rgba(13, 22, 33, 0.3253676470588235) 100%);
        background: -webkit-linear-gradient(328deg, rgba(13, 22, 33, 1) 71%, rgba(21, 29, 77, 0.4654236694677871) 100%, rgba(30, 38, 131, 0.5970763305322129) 100%, rgba(18, 19, 19, 1) 100%, rgba(6, 122, 150, 1) 100%, rgba(13, 22, 33, 0.3253676470588235) 100%);
        background: linear-gradient(328deg, rgba(13, 22, 33, 1) 71%, rgba(21, 29, 77, 0.4654236694677871) 100%, rgba(30, 38, 131, 0.5970763305322129) 100%, rgba(18, 19, 19, 1) 100%, rgba(6, 122, 150, 1) 100%, rgba(13, 22, 33, 0.3253676470588235) 100%);
        filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#0d1621", endColorstr="#0d1621", GradientType=1);
    }

    ::-webkit-scrollbar {
        width: 3px;

    }

    ::-webkit-scrollbar-track {
        background: black;

        border-radius: 10px;

    }

    ::-webkit-scrollbar-thumb {
        background: #0f0f11;

        border-radius: 10px;

    }

    ::-webkit-scrollbar-thumb:hover {
        background: #0f0f11;

    }

    .bg-cards {
            background-color: #0c0c0c;
            border: 1px solid #1d1d1d72;
        }

    .bg-icon {
        background-color: #0f0f11;
        box-shadow: 0px 0px 4px #000;
        border: 1px solid #1d1d1d;
    }

    .border-devider {
        border-color: #1d1d1d;

    }

    .border-global {
        border: 1px solid #1d1d1d;
    }

    .bg-url {
        background-color: #171719;
        border: 1px solid #1d1d1d;
    }

    .w-custom {
        width: fit-content;
    }



    /* Mobile-specific styles */
    @media (max-width: 640px) {
        .hid {
            display: none;
        }
    }

    .dark-mode-popup {
        background-color: rgb(13, 22, 33) !important;
        color: white !important;
    }

    .dark-mode-title {
        color: white !important;
    }

    .dark-mode-content {
        color: white !important;
    }

    .h-custom {
        height: 27rem;
    }

    .bg-icons {
        background-color: #0c0c0e;
    }

    .header {
        position: relative;
        background-image: url("https://wallpaperaccess.com/full/2984692.jpg");
        background-size: cover;
        background-position: center;
        height: 200px;
        color: white;
    }

    .header::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(to bottom, rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 1));
        z-index: 1;
    }

    .header>* {
        position: relative;
        z-index: 2;
    }
</style>


<aside id="logo-sidebar"
    class="fixed top-0 left-0 z-40 w-64 h-screen pt-20 transition-transform -translate-x-full bg-sidebar border-sidebar sm:translate-x-0"
    aria-label="Sidebar">
    <div class="h-full px-3 pb-4 overflow-y-auto bg-sidebar">
        <ul id="sidebar-links" class="space-y-2 font-medium">

        </ul>
    </div>
</aside>





<div class="container mx-auto bg-cards text-white rounded-md shadow-md">
        @if ($allocations)
            <div class="overflow-x-auto ">
                <table class="min-w-full bg-cards text-white rounded-md">
                    <thead>
                        <tr class="text-left bg-cards">
                            <th class="py-2 text-sm font-semibold text-gray-300 px-4">ID</th>
                            <th class="py-2 text-sm font-semibold text-gray-300 px-4">IP Address</th>
                            <th class="py-2 text-sm font-semibold text-gray-300 px-4">Port</th>
                            <th class="py-2 text-sm font-semibold text-gray-300 px-4"></th>
                        </tr>
                    </thead>
                    <tbody class="pt-2">
                        @foreach ($allocations as $allocation)
                            <tr class="hover:bg-cards pt-2">
                                <td class="py-2 px-4">{{ $allocation['attributes']['id'] }}</td>
                                <td class="py-2 px-4"><span
                                        class="bg-cards rounded-lg p-1">{{ $allocation['attributes']['ip'] }}</span></td>
                                <td class="py-2 px-4"><span
                                        class="bg-cards rounded-lg p-1">{{ $allocation['attributes']['port'] }}</span></td>
                                <td class="py-2 px-4"><span
                                        class="bg-blue-600 rounded-lg p-1">{{ $allocation['attributes']['is_default'] ? 'Primary' : 'Not Primary' }}</span>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @else
            <p class="text-gray-400">No allocations available.</p>
        @endif
    </div>



    <div class="footer items-center bottom-0 w-full text-gray-400 py-4 mt-4">
  <div class="text-center">
    <h1 class="text-sm">
      Made with <i class="fa-solid text-red-700 fa-heart"></i> by
      <a class="underline text-blue-600" href="https://anthonys.pro">Anthony S</a>
    </h1>
  </div>
</div>



<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<script>
    const sidebarLinks = [
        {
            title: 'Console',
            icon: 'fa-code',
            url: 'console',
            active: false,
        },
        {
            title: 'File Manager',
            icon: 'fa-folder',
            url: 'file-manager',
        },
        {
            title: 'Plugin Manager',
            icon: 'fa-box',
            url: 'plugins',
            hasDivider: false,
        },
        {
            title: 'Backups',
            icon: 'fa-download',
            url: 'backups',
        },
        {
            title: 'Databases',
            icon: 'fa-database',
            url: 'database',
            active: false,

        },
        {
            title: 'Network',
            icon: 'fa-network-wired',
            url: 'network',
            active: true,
        },
        {
            title: 'Settings',
            icon: 'fa-gears',
            url: 'settings',
        },
    ];

    function generateSidebarLinks() {
        const sidebarLinksContainer = document.getElementById('sidebar-links');
        sidebarLinks.forEach(link => {
            const listItem = document.createElement('li');
            const activeClass = link.active ? 'bg-url' : '';

            listItem.innerHTML = `
            <a href="${link.url}" class="flex items-center p-2 text-gray-900 rounded-lg dark:text-white group transform transition-transform hover:scale-105 ${activeClass}">
                <i class="fa-solid fa-lg text-gray-300 ${link.icon}"></i>
                <span class="flex-1 ms-3 whitespace-nowrap">${link.title}</span>
            </a>
        `;

            sidebarLinksContainer.appendChild(listItem);
            if (link.hasDivider) {
                const divider = document.createElement('div');
                divider.classList.add('border-custom');
                sidebarLinksContainer.appendChild(divider);
            }
        });
    }

    document.addEventListener('DOMContentLoaded', generateSidebarLinks);

</script>

</html>
@endsection
