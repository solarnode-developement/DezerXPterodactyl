@extends('server.layouts.app')

@section('title', 'Console')

@section('content')
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .console-container {
            background: rgb(13, 22, 33);
            background: -moz-linear-gradient(328deg, rgba(13, 22, 33, 1) 71%, rgba(21, 29, 77, 0.4654236694677871) 100%, rgba(30, 38, 131, 0.5970763305322129) 100%, rgba(18, 19, 19, 1) 100%, rgba(6, 122, 150, 1) 100%, rgba(13, 22, 33, 0.3253676470588235) 100%);
            background: -webkit-linear-gradient(328deg, rgba(13, 22, 33, 1) 71%, rgba(21, 29, 77, 0.4654236694677871) 100%, rgba(30, 38, 131, 0.5970763305322129) 100%, rgba(18, 19, 19, 1) 100%, rgba(6, 122, 150, 1) 100%, rgba(13, 22, 33, 0.3253676470588235) 100%);
            background: linear-gradient(328deg, rgba(13, 22, 33, 1) 71%, rgba(21, 29, 77, 0.4654236694677871) 100%, rgba(30, 38, 131, 0.5970763305322129) 100%, rgba(18, 19, 19, 1) 100%, rgba(6, 122, 150, 1) 100%, rgba(13, 22, 33, 0.3253676470588235) 100%);
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#0d1621", endColorstr="#0d1621", GradientType=1);
        }

        ::-webkit-scrollbar {
            width: 3px;

        }

        ::-webkit-scrollbar-track {
            background: black;

            border-radius: 10px;

        }

        ::-webkit-scrollbar-thumb {
            background: #0f0f11;

            border-radius: 10px;

        }

        ::-webkit-scrollbar-thumb:hover {
            background: #0f0f11;

        }

        .bg-cards {
            background-color: #0c0c0c;
            border: 1px solid #1d1d1d46;
        }

        .bg-icon {
            background-color: #0f0f11;
            box-shadow: 0px 0px 4px #000;
            border: 1px solid #1d1d1d72;
        }

        .border-devider {
            border-color: #1d1d1d72;

        }

        .border-global {
            border: 1px solid #1d1d1d72;
        }

        .bg-url {
            background-color: #171719;
            border: 1px solid #1d1d1d72;
        }

        .w-custom {
            width: fit-content;
        }



        /* Mobile-specific styles */
        @media (max-width: 640px) {
            .hid {
                display: none;
            }
        }

        .dark-mode-popup {
            background-color: rgb(13, 22, 33) !important;
            color: white !important;
        }

        .dark-mode-title {
            color: white !important;
        }

        .dark-mode-content {
            color: white !important;
        }

        .h-custom {
            height: 27rem;
        }

        .bg-icons {
            background-color: #080809;
        }

        .header {
            position: relative;
            background-size: cover;
            background-position: center;
            height: 100px;
            background-image: url("https://wallpaperaccess.com/full/2984692.jpg");

            color: white;
        }

        .header::before {
            content: "";
            position: absolute;
            top: 0;

            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(to bottom, rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 1));
            z-index: 1;
        }

        .header>* {
            position: relative;
            z-index: 2;
        }
    </style>


    <aside id="logo-sidebar"
        class="fixed top-0 left-0 z-40 w-64 h-screen pt-20 transition-transform -translate-x-full bg-sidebar border-sidebar sm:translate-x-0"
        aria-label="Sidebar">
        <div class="h-full px-3 pb-4 overflow-y-auto bg-sidebar">
            <ul id="sidebar-links" class="space-y-2 font-medium">

            </ul>
        </div>
    </aside>


    <div class="flex items-center justify-between">
        <div class="text-left flex flex-col ">
            <span class="text-gray-100 text-2xl font-bold">Manage {{ $serverDetails['name'] }}</span>
            <span class="text-gray-400">Manage your instance here using DezerX panel!</span>
        </div>


        <div class="flex space-x-2">
            <button data-action="start" id="start-button"
                class="bg-green-700 text-white px-3 py-2 rounded-xl border border-green-700">
                <i class="fa-solid mr-2 fa-play"></i> Start
            </button>

            <button data-action="stop" id="stop-button"
                class="bg-red-700 text-white px-3 py-2 rounded-xl border border-red-700">
                <i class="fa-solid mr-2 fa-square"></i> Stop
            </button>
            <button data-action="restart" id="restart-button"
                class="bg-blue-700 text-white px-3 py-2 rounded-xl border border-blue-700">
                <i class="fa-solid mr-2 fa-arrow-rotate-right"></i> Restart
            </button>
        </div>
    </div>

    <div class="flex flex-col md:flex-row gap-4 mt-4 w-full">
        <div class="px-4 py-3 bg-cards  rounded-lg shadow-md flex-1 flex justify-between items-center">
            <div>
                <h3 class="text-lg text-gray-400 font-semibold">IP Address</h3>
                <div class=" text-gray-200 text-lg font-bold" id="cpu-usage">{{ $serverDetails['ip'] }}</div>
            </div>
            <i class="fa-solid fa-network-wired text-white p-2 rounded-lg bg-icons text-2xl"></i>
        </div>

        <div class="px-4 py-3 bg-cards  rounded-lg shadow-md flex-1 flex justify-between items-center">
            <div>
                <h3 class="text-lg text-gray-400 font-semibold">Memory Usage</h3>
                <div class=" text-gray-200 text-lg font-bold" id="ram-stats">N/A</div>
            </div>
            <i class="fa-solid fa-memory text-white p-2 rounded-lg bg-icons text-2xl"></i>
        </div>

        <div class="px-4 py-3 bg-cards  rounded-lg shadow-md flex-1 flex justify-between items-center">
            <div>
                <h3 class="text-lg text-gray-400 font-semibold">Cpu Usage</h3>
                <div class=" text-gray-200 text-lg font-bold" id="cpu-stats">N/A</div>
            </div>
            <i class="fa-solid fa-microchip text-white p-2 rounded-lg bg-icons text-2xl"></i>
        </div>
    </div>




    <div class="flex flex-col w-full md:flex-row">

        <div class="flex flex-col w-full">
            <div class="bg-black rounded-3xl border border-zinc-900 p-1 mt-4 bd-8 text-white shadow-lg w-full">
                <div id="console" class="h-custom overflow-y-auto p-4 bg-black font-mono text-sm">
                </div>
                <div class="flex items-center p-2 mt-2">
                    <input type="text" id="console-input"
                        class="w-full bg-cards  text-white px-3 py-2 rounded-2xl focus:outline-none focus:ring-2 focus:ring-gray-500"
                        placeholder="$ Type a command...">
                </div>

            </div>

        </div>
    </div>

    <div class="footer items-center bottom-0 w-full text-gray-400 py-4 mt-4">
        <div class="text-center">
            <h1 class="text-sm">
                Made with <i class="fa-solid text-red-700 fa-heart"></i> by
                <a class="underline text-blue-600" href="https://anthonys.pro">Anthony S</a>
            </h1>
        </div>
    </div>


    <script src="{{ asset('ansi_up.min.js') }}"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const token = '{{ $websocketToken }}';
            const wsUrl = '{{ $websocketUrl }}';
            let ws = new WebSocket(wsUrl);
            const ansiUp = new AnsiUp();
            const consoleDiv = document.getElementById('console');

            let isTokenRequestSent = false;

            function requestNewToken() {
                if (ws.readyState === WebSocket.OPEN) {
                    if (!isTokenRequestSent) {
                        ws.send(JSON.stringify({
                            event: 'token expiring',
                            args: [null]
                        }));
                        console.log('Token expiring event sent.');
                        isTokenRequestSent = true;
                    }
                } else {
                    console.error('WebSocket connection is not open for token refresh.');
                }
            }

            function handleTokenExpired() {
                console.log('Token expired, reconnecting...');
                ws.close();
                reconnectWebSocket();
                isTokenRequestSent = false;
            }


            function reconnectWebSocket() {
                const newWs = new WebSocket(wsUrl);
                newWs.onopen = () => {
                    console.log('WebSocket reconnected');
                    newWs.send(JSON.stringify({
                        event: 'auth',
                        args: [token]
                    }));
                    requestStats();
                    isTokenRequestSent = false;
                };

                newWs.onmessage = (event) => {
                    const message = JSON.parse(event.data);
                    handleWebSocketMessage(message, newWs);
                };

                newWs.onclose = () => {
                    console.log('WebSocket connection closed');
                    localStorage.removeItem('consoleLogs');
                };

                newWs.onerror = (error) => {
                    console.error('WebSocket error', error);
                };

                ws = newWs;
            }

            function requestStats() {
                if (ws.readyState === WebSocket.OPEN) {
                    ws.send(JSON.stringify({
                        event: 'send stats',
                        args: [null]
                    }));
                }
            }

            const oldLogs = localStorage.getItem('consoleLogs');
            if (oldLogs) {
                consoleDiv.innerHTML = oldLogs.replace(/&gt;/g, '');
                consoleDiv.scrollTop = consoleDiv.scrollHeight;
            }

            ws.onopen = () => {
                console.log('WebSocket connection established');
                ws.send(JSON.stringify({
                    event: 'auth',
                    args: [token]
                }));
                requestStats();
            };

            ws.onmessage = (event) => {
                const message = JSON.parse(event.data);

                let output = '';
                switch (message.event) {
                    case 'console output':
                        output = ansiUp.ansi_to_html(message.args[0]).replace(/&gt;/g, '');
                        break;

                    case 'auth success':
                        console.log('Authentication successful');
                        break;

                    case 'stats':
                        const stats = JSON.parse(message.args[0]);
                        if (stats.status === 'offline') {
                            consoleDiv.innerHTML += `<div style="color: red;">[Dezer] Server Offline</div>`;
                            localStorage.removeItem('consoleLogs');
                        } else {
                            updateStats(stats);
                        }
                        break;

                    case 'status':
                        const status = message.args[0];
                        if (status === 'offline') {
                            consoleDiv.innerHTML +=
                                `<span>[<span class="text-blue-600">Dezer Dash</span><span>]</span> <span>Server is</span><span class="text-red-500"> Offline</span><span>!</span>`;
                            localStorage.removeItem('consoleLogs');
                        }
                        break;

                    case 'daemon error':
                        displayDaemonError(message.args[0]);
                        break;

                    case 'install output':
                        output = ansiUp.ansi_to_html(message.args[0]).replace(/&gt;/g, '');
                        output = `<div style="color: orange;">"${output}"</div>`;
                        break;

                    default:
                        output = `<div>${JSON.stringify(message)}</div>`;
                        break;
                }

                if (output) {
                    consoleDiv.innerHTML += `<div>${output}</div>`;
                    consoleDiv.scrollTop = consoleDiv.scrollHeight;
                    localStorage.setItem('consoleLogs', consoleDiv.innerHTML);
                }
            };

            ws.onclose = () => {
                console.log('WebSocket connection closed');
                localStorage.removeItem('consoleLogs');
            };

            ws.onerror = (error) => {
                console.error('WebSocket error', error);
            };

            document.getElementById('console-input').addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    const command = e.target.value.trim();
                    if (command && ws.readyState === WebSocket.OPEN) {
                        ws.send(JSON.stringify({
                            event: 'send command',
                            args: [command]
                        }));
                        e.target.value = '';
                        console.log(`Sent command: ${command}`);
                    }
                }
            });

            function updateStats(stats) {
                const ramUsage = (stats.memory_bytes / (1024 * 1024)).toFixed(2);
                document.getElementById('ram-stats').innerText =
                    `${ramUsage}MB / {{ $serverDetails['limits']['memory'] }}MB`;

                const cpuUsage = (stats.cpu_absolute).toFixed(2);
                document.getElementById('cpu-stats').innerText =
                    `${cpuUsage}% / {{ $serverDetails['limits']['cpu'] }}%`;

                const diskUsage = (stats.disk_bytes / (1024 * 1024)).toFixed(2);
                const diskLimit = (stats.disk_limit_bytes / (1024 * 1024)).toFixed(2);
                document.getElementById('disk-stats').innerText =
                    `${diskUsage}MB /{{ $serverDetails['limits']['disk'] / 1024 }}GB`;
            }

            function displayDaemonError(error) {
                const errorElement = document.getElementById('daemon-error');
                errorElement.innerText = `Daemon Error: ${error}`;
                errorElement.style.color = 'red';
            }

            document.querySelectorAll('button[data-action]').forEach(button => {
                button.addEventListener('click', () => {
                    const action = button.getAttribute('data-action');
                    if (ws.readyState === WebSocket.OPEN) {
                        ws.send(JSON.stringify({
                            event: 'set state',
                            args: [action]
                        }));
                        console.log(`Sent action: ${action}`);
                    } else {
                        console.error('WebSocket connection is not open');
                    }
                });
            });

            setInterval(requestNewToken, 600000);
        });
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const startButton = document.getElementById('start-button');
            const stopButton = document.getElementById('stop-button');

            function showNotification(icon, title, text, footer = '') {
                Swal.fire({
                    icon: icon,
                    title: title,
                    text: text,
                    footer: footer,
                    background: 'rgb(13, 22, 33)',
                    r
                    customClass: {
                        popup: 'dark-mode-popup',
                        title: 'dark-mode-title',
                        content: 'dark-mode-content',
                        confirmButton: 'dark-mode-confirm-button'
                    }
                });
            }

            startButton.addEventListener('click', function() {
                showNotification(
                    'success',
                    'Start Action',
                    'The start action was triggered.'
                );
            });

            stopButton.addEventListener('click', function() {
                showNotification(
                    'success',
                    'Stop Action',
                    'The stop action was triggered.'

                );

            });
        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const openModalButton = document.getElementById('open-modal');

            function showNotification(icon, title, text, footer = '') {
                Swal.fire({
                    icon: icon,
                    title: title,
                    text: text,
                    footer: footer,
                    background: 'rgb(13, 22, 33)',
                    customClass: {
                        popup: 'dark-mode-popup',
                        title: 'dark-mode-title',
                        content: 'dark-mode-content',
                        confirmButton: 'dark-mode-confirm-button'
                    }
                });
            }

            openModalButton.addEventListener('click', function() {
                showNotification(
                    'info',
                    'Connection Details',
                    '{{ $serverDetails['ip'] }}'

                );

            });
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    </>

    <script>
        const sidebarLinks = [{
                title: 'Console',
                icon: 'fa-code',
                url: 'console',
                active: true,
            },
            {
                title: 'File Manager',
                icon: 'fa-folder',
                url: 'file-manager',
            },
            {
                title: 'Plugin Manager',
                icon: 'fa-box',
                url: 'plugins',
                hasDivider: false,
            },
            {
                title: 'Backups',
                icon: 'fa-download',
                url: 'backups',
            },
            {
                title: 'Databases',
                icon: 'fa-database',
                url: 'database',
                active: false,

            },
            {
                title: 'Network',
                icon: 'fa-network-wired',
                url: 'network',
            },
            {
                title: 'Settings',
                icon: 'fa-gears',
                url: 'settings',
            },
        ];

        function generateSidebarLinks() {
            const sidebarLinksContainer = document.getElementById('sidebar-links');
            sidebarLinks.forEach(link => {
                const listItem = document.createElement('li');
                const activeClass = link.active ? 'bg-url' : '';

                listItem.innerHTML = `
            <a href="${link.url}" class="flex items-center p-2 text-gray-900 rounded-lg dark:text-white group transform transition-transform hover:scale-105 ${activeClass}">
                <i class="fa-solid fa-lg text-gray-300 ${link.icon}"></i>
                <span class="flex-1 ms-3 whitespace-nowrap">${link.title}</span>
            </a>
        `;

                sidebarLinksContainer.appendChild(listItem);
                if (link.hasDivider) {
                    const divider = document.createElement('div');
                    divider.classList.add('border-custom');
                    sidebarLinksContainer.appendChild(divider);
                }
            });
        }

        document.addEventListener('DOMContentLoaded', generateSidebarLinks);
    </script>

    </html>
@endsection
