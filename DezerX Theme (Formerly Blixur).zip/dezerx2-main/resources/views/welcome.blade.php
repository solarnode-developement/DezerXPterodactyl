<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Welcome!</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;600&display=swap" rel="stylesheet">
</head>
<style>
    .bg-cards {
        background-color: #0c0c0c;
        border: 1px solid #1d1d1d72;
        font-family: "Quicksand", sans-serif;

    }

    .bg-cards-1 {
        background-color: #000;
        border: 1px solid #1d1d1d72;
        font-family: "Quicksand", sans-serif;

    }

    body {
        background-color: #000;
        font-family: Quicksand, sans-serif;
        background-image: linear-gradient(0deg, rgba(34, 34, 34, .404) 1px, transparent 0), linear-gradient(90deg, rgba(34, 34, 34, .404) 1px, transparent 0);
        background-size: 90px 90px;
        position: relative
    }

    body:before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 1;
        background: radial-gradient(circle at top left, rgba(0, 0, 0, .664), transparent 70%) 0 0, radial-gradient(circle at top right, rgba(0, 0, 0, .6), transparent 70%) 100% 0, radial-gradient(circle at bottom left, rgba(0, 0, 0, .6), transparent 70%) 0 100%, radial-gradient(circle at bottom right, rgba(0, 0, 0, .6), transparent 70%) 100% 100%;
        background-size: 50% 50%;
        background-repeat: no-repeat
    }
</style>
@php
    $ad = \App\Models\Ad::first();
@endphp
@php
    // Fetch the count of registered users
    $userCount = \App\Models\User::count();
@endphp
@php
    // Fetch the count of registered users
    $serverCount = \App\Models\Server::count();
@endphp
@php
    // Fetch the count of registered users
    $packageCount = \App\Models\Package::count();
@endphp
@php
    $packages = \App\Models\Package::all();
@endphp

<body class="bg-black text-white">

    <nav class=" p-4 shadow-md">
        <div class="container mx-auto flex justify-between items-center">
            <!-- Logo and Title -->
            <a href="/dashboard" class="text-white text-2xl font-bold"> {{ $ad->name ?? 'DezerX' }}</a>

            <!-- Desktop Menu -->
            <div class="hidden md:flex space-x-4">
                <a href="/login" class="text-white mt-2 hover:text-gray-300">Login</a>
                <a href="/register"
                    class="text-gray-300 bg-blue-800 z-50 rounded-full px-5 py-2 blue-shadow hover:text-white"
                    style="will-change: auto; transform: none;"><i class="fa-solid fa-user"></i> Register</a>
            </div>

            <!-- Mobile Menu Button -->
            <div class="md:hidden flex items-center">
                <button id="menuButton" class="text-white focus:outline-none">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M4 6h16M4 12h16m-7 6h7"></path>
                    </svg>
                </button>
            </div>
        </div>

        <!-- Mobile Menu -->
        <div id="mobileMenu" class="md:hidden absolute top-16 left-0 w-full bg-gray-800 text-white hidden">
            <a href="/login" class="block px-4 py-2 hover:bg-gray-700">Login</a>
            <a href="https://discord.gg/UN4VVc2hWJ"
                class="text-gray-300 bg-blue-800 z-50 rounded-full px-5 py-2 blue-shadow hover:text-white"
                style="will-change: auto; transform: none;"><i class="fa-brands fa-discord"></i> Discord</a>
        </div>
    </nav>

    <header class=" text-center mt-7 py-16 flex flex-col items-center justify-center">
        <div class="bg-black w-auto py-1 px-5 mb-3 border-b rounded-full border-t border-gray-800 border-r flex items-center"
            style="opacity: 1; will-change: auto; transform: none;"><i
                class="fa-solid fa-sm text-gray-400 fa-heart text-xl mr-2"></i><span
                class="text-md text-gray-400 font-md">Get Started Now!</span></div>
        <h1 class="text-6xl font-bold mb-4">All-In-One Solution
            <br> With {{ $ad->name ?? 'DezerX' }}
        </h1>
        <p class="text-lg text-gray-400 mb-8">Ready to start your own minecraft server but don't know where to start?
            Check out {{ $ad->name ?? 'DezerX' }},<br> your ultimate solution for launching and managing hosting
            <br>services effortlessly!!
        </p>
        <div class="bg-cards-1 border-t border-l p-2 w-[400px] rounded-full flex items-center justify-between"
            style="opacity: 1; will-change: auto; transform: none;">
            <span class="text-gray-400 text-md font-medium flex items-center">
                <i class="fa-solid fa-lg mr-2 ml-3 fa-circle-info"></i> Ready to get started?
            </span>
            <button class="bg-blue-800 text-white blue-shadow px-10 py-2 rounded-full">yessir!!!</button>
        </div>
    </header>


    <section class="grid grid-cols-1 mb-6 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl w-full mx-auto">
        <div class="bg-cards text-white p-6 rounded-lg shadow-lg flex items-center">
            <div class="flex flex-1 items-center">
                <p class="text-3xl font-bold">{{ $userCount }}+</p>
                <h2 class="text-sm font-semibold ml-4">Registered Users</h2>
            </div>
            <i class="fas fa-user ml-4 text-xl"></i>
        </div>

        <div class="bg-cards text-white p-6 rounded-lg shadow-lg flex items-center">
            <div class="flex-1 flex items-center">
                <p class="text-3xl font-bold">{{ $serverCount }}+</p>
                <h2 class="text-sm font-semibold ml-4">Servers</h2>
            </div>
            <i class="fas fa-server ml-4 text-xl"></i>
        </div>

        <div class="bg-cards text-white p-6 rounded-lg shadow-lg flex items-center">
            <div class="flex-1 flex items-center">
                <p class="text-3xl font-bold">{{ $packageCount }}</p>
                <h2 class="text-sm font-semibold ml-4">Packages!</h2>
            </div>
            <i class="fa-solid fa-boxes-stacked"></i>
        </div>

    </section>

    <section class="bg-black py-12">
        <div class="max-w-7xl mx-auto px-6 lg:px-8">
            <h2 class="text-3xl font-bold text-center text-white mb-8">Our Pricing Plans</h2>
            <div class="flex justify-center">
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
                    @foreach($packages as $package)
                    <div class="bg-cards text-white p-6 rounded-lg shadow-lg flex flex-col items-center">
                        <img src="{{ $package->image }}" alt="{{ $package->title }}" class="w-24 h-24 mb-4 rounded-full object-cover">
                        <h3 class="text-xl font-semibold mb-2">{{ $package->title }}</h3>
                        <p class="text-lg font-bold mb-4"><i class="fa-solid fa-coins"></i> {{ $package->price }}</p>
                        <div class="flex flex-col md:flex-row justify-between w-full mb-4">
                            <div class="flex flex-col space-y-2 mr-4">
                                <p>RAM: {{ $package->ram }} GB</p>
                                <p>CPU: {{ $package->cpu }} Cores</p>
                                <p>Disk: {{ $package->disk }} GB</p>
                            </div>
                            <div class="flex flex-col space-y-2">
                                <p>Slots: {{ $package->slots }}</p>
                                <p>Databases: {{ $package->databases }}</p>
                                <p>Ports: {{ $package->ports }}</p>
                            </div>
                        </div>
                        <button class="bg-blue-800 text-white px-6 py-2 rounded-full hover:bg-blue-700 transition duration-300">Select Plan</button>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
    </section>
    
    
    
    <script>
        document.getElementById('menuButton').addEventListener('click', function() {
            const mobileMenu = document.getElementById('mobileMenu');
            mobileMenu.classList.toggle('hidden');
        });
    </script>

</body>

</html>
