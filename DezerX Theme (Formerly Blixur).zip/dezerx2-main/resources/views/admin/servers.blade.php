@extends('admin.layouts.app')

@section('title', 'View Users')

@section('content')
    <style>
        .bg-cards {
            background-color: #0f0f11;
            border: 1px solid #1d1d1d;
        }

        .bg-cards-1 {
            background-color: #070707;
            border: 1px solid #1d1d1d;
        }

        .bg-icon {
            background-color: #0f0f11;
            box-shadow: 0px 0px 4px #000;
            border: 1px solid #1d1d1d;
        }

        .border-devider {
            border-color: #1d1d1d;

        }

        .border-bottom-1 {
            border-bottom: 1px solid #1d1d1d;
        }

        .border-global {
            border: 1px solid #1d1d1d;
        }

        .bg-url {
            background-color: #171719;
            border: 1px solid #1d1d1d;
        }

        .w-custom {
            width: fit-content;
        }
    </style>

    <aside id="logo-sidebar"
        class="fixed top-0 left-0 z-40 w-64 h-screen pt-20 transition-transform -translate-x-full bg-sidebar border-sidebar sm:translate-x-0"
        aria-label="Sidebar">
        <div class="h-full px-3 pb-4 overflow-y-auto bg-sidebar">
            <ul id="sidebar-links" class="space-y-2 font-medium">

            </ul>
        </div>
    </aside>



    <table class="min-w-full bg-cards shadow-lg" style="border-bottom: 1px solid rgb(31 41 55 / 30%);">
        <thead class="">
            <div class="bg-cards-1 p-2 w-full"
                style="border-top: 2px solid #2536EB; border-bottom: 1px solid rgb(31 41 55 / 30%)">
                <h1 class="font-semibold text-xl text-white"> Servers List </h1>
            </div>
            <tr>
                <th class="py-2 px-4 text-left text-gray-300">ID</th>
                <th class="py-2 px-4 text-left text-gray-300">Name</th>
                <th class="py-2 px-4 text-left text-gray-300">Description</th>
                <th class="py-2 px-4 text-left text-gray-300">User ID</th>
                <th class="py-2 px-4 text-left text-gray-300">Server ID</th>
                <th class="py-2 px-4 text-left text-gray-300">RAM</th>
                <th class="py-2 px-4 text-left text-gray-300">CPU</th>
                <th class="py-2 px-4 text-left text-gray-300">Disk</th>
                <th class="py-2 px-4 text-left text-gray-300">Location ID</th>
                <th class="py-2 px-4 text-left text-gray-300">Last Billed At</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($servers as $server)
                <tr>
                    <td class="py-2 px-4 text-left text-gray-300">{{ $server->id }}</td>
                    <td class="py-2 px-4 text-left text-gray-300">{{ $server->name }}</td>
                    <td class="py-2 px-4 text-left text-gray-300">{{ $server->description }}</td>
                    <td class="py-2 px-4 text-left text-gray-300">{{ $server->user_id }}</td>
                    <td class="py-2 px-4 text-left text-gray-300">{{ $server->owner_id }}</td>
                    <td class="py-2 px-4 text-left text-gray-300">{{ $server->ram }}</td>
                    <td class="py-2 px-4 text-left text-gray-300">{{ $server->cpu }}</td>
                    <td class="py-2 px-4 text-left text-gray-300">{{ $server->disk }}</td>
                    <td class="py-2 px-4 text-left text-gray-300">{{ $server->location_id }}</td>
                    <td class="py-2 px-4 text-left text-gray-300">{{ $server->last_billed_at ?? 'N/A' }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
    

<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.editable-credits').forEach(function (input) {
        input.addEventListener('blur', function () {
            let newCredits = this.value;
            let userId = this.getAttribute('data-id');

            fetch(`/admin/users/${userId}/update-credits`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
                body: JSON.stringify({ credits: newCredits })
            }).then(response => {
                if (!response.ok) {
                    alert('Failed to update credits');
                }
            }).catch(error => {
                console.error('Error:', error);
            });
        });
    });
});
</script>



    <script>
        const sidebarLinks = [{
                title: 'Overview',
                icon: 'fa-desktop',
                url: 'dashboard',
            },
            {
                title: 'Users',
                icon: 'fa-users',
                url: 'users',
                active: false,
            },
            {
                title: 'Products',
                icon: 'fa-box',
                url: 'products',
            },
            {
                title: 'Settings',
                icon: 'fa-gear',
                url: 'settings',
                hasDivider: true,
            },
            {
                title: 'Servers',
                icon: 'fa-server',
                url: 'servers',
                active: true,

            },
            {
            title: 'Images',
            icon: 'fa-egg',
            url: '{{ route('admin.eggs') }}',
        },
        ];

        function generateSidebarLinks() {
            const sidebarLinksContainer = document.getElementById('sidebar-links');
            sidebarLinks.forEach(link => {
                const listItem = document.createElement('li');
                const activeClass = link.active ? 'bg-url' : '';

                listItem.innerHTML = `
            <a href="${link.url}" class="flex items-center p-2 text-gray-900 rounded-lg dark:text-white group transform transition-transform hover:scale-105 ${activeClass}">
                <i class="fa-solid fa-lg text-gray-300 ${link.icon}"></i>
                <span class="flex-1 ms-3 whitespace-nowrap">${link.title}</span>
            </a>
        `;

                sidebarLinksContainer.appendChild(listItem);
                if (link.hasDivider) {
                    const divider = document.createElement('div');
                    divider.classList.add('border-custom');
                    sidebarLinksContainer.appendChild(divider);
                }
            });
        }

        document.addEventListener('DOMContentLoaded', generateSidebarLinks);
    </script>
@endsection
