@extends('admin.layouts.app')

@section('title', 'Images')
@php
    $eggs = \App\Models\Egg::first();
@endphp
@section('content')
    <style>
        .bg-cards {
            background-color: #0f0f11;
            border: 1px solid #1d1d1d;
        }

        .bg-cards-1 {
            background-color: #070707;
            border: 1px solid #1d1d1d;
        }

        .bg-icon {
            background-color: #0f0f11;
            box-shadow: 0px 0px 4px #000;
            border: 1px solid #1d1d1d;
        }

        .border-devider {
            border-color: #1d1d1d;

        }

        .border-bottom-1 {
            border-bottom: 1px solid #1d1d1d;
        }

        .border-global {
            border: 1px solid #1d1d1d;
        }

        .bg-url {
            background-color: #171719;
            border: 1px solid #1d1d1d;
        }

        .w-custom {
            width: fit-content;
        }
    </style>

    <aside id="logo-sidebar"
        class="fixed top-0 left-0 z-40 w-64 h-screen pt-20 transition-transform -translate-x-full bg-sidebar border-sidebar sm:translate-x-0"
        aria-label="Sidebar">
        <div class="h-full px-3 pb-4 overflow-y-auto bg-sidebar">
            <ul id="sidebar-links" class="space-y-2 font-medium">

            </ul>
        </div>
    </aside>


    <div class="flex flex-col justify-center">
        <div class="flex flex-col lg:flex-row lg:space-y-0 lg:space-x-4">
          
        </div>     
    </div>
    
    @php
    $eggs = \App\Models\Egg::all();
@endphp
<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body class=" text-white">
    <div class="container mx-auto ">
        <!-- Table -->
        <div class="relative">
            <table class="min-w-full bg-cards shadow-lg">
                <thead>
                    <div class="bg-cards-1 p-2 w-full" style="border-top: 2px solid #2536EB; border-bottom: 1px solid rgb(31 41 55 / 30%)">
                        <h1 class="font-semibold text-xl text-white">Eggs List</h1>
                        <!-- Plus Icon Button -->
                        <button onclick="toggleModal()" class="absolute top-2 right-2 p-2 text-white">
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>
                    <tr>
                        <th class="py-2 px-4 text-left text-gray-300">Egg ID</th>
                        <th class="py-2 px-4 text-left text-gray-300">Name</th>
                        <th class="py-2 px-4 text-left text-gray-300">Description</th>
                        <th class="py-2 px-4 text-left text-gray-300">Nest ID</th>
                        <th class="py-2 px-4 text-left text-gray-300">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($eggs as $egg)
                        <tr>
                            <form action="{{ route('admin.eggs.update', $egg->id) }}" method="POST">
                                @csrf
                                @method('PUT')
                                <td class="py-2 px-4 text-white text-left">
                                    <input type="text" name="egg_id" value="{{ $egg->egg_id }}" class="editable-egg p-2 rounded bg-zinc-950">
                                </td>
                                <td class="py-2 px-4 text-white text-left">
                                    <input type="text" name="name" value="{{ $egg->name }}" class="editable-egg p-2 rounded bg-zinc-950">
                                </td>
                                <td class="py-2 px-4 text-white text-left">
                                    <input type="text" name="description" value="{{ $egg->description }}" class="editable-egg p-2 rounded bg-zinc-950">
                                </td>
                                <td class="py-2 px-4 text-white text-left">
                                    <input type="text" name="nest_id" value="{{ $egg->nest_id }}" class="editable-egg p-2 rounded bg-zinc-950">
                                </td>
                               
                                <td class="py-2 px-4 text-red-800 text-left">
                                    <form action="{{ route('admin.eggs.destroy', $egg->id) }}" method="POST">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit">Delete</button>
                                    </form>
                                </td>
                            </form>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        <!-- Modal -->
        <div id="createEggModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden">
            <div class="bg-zinc-950 border border-zinc-800 p-6 rounded-lg w-full max-w-md">
                <h2 class="text-xl font-semibold mb-4">Create New Egg</h2>
                <form action="{{ route('admin.eggs.store') }}" method="POST">
                    @csrf
                    <div class="mb-4">
                        <label for="name" class="block mb-2 text-gray-300">Name</label>
                        <input type="text" id="name" placeholder="Paper" name="name" class="w-full p-2 bg-black border border-zinc-800 text-white rounded" required>
                    </div>
                    <div class="mb-4">
                        <label for="description" class="block mb-2 text-gray-300">Description</label>
                        <input type="text" id="description" name="description" class="w-full p-2 bg-black border border-zinc-800 text-white rounded" required>
                    </div>
                    <div class="mb-4">
                        <label for="egg_id" class="block mb-2 text-gray-300">Egg ID</label>
                        <input type="number" placeholder="4" id="egg_id" name="egg_id" class="w-full p-2 bg-black border border-zinc-800 text-white rounded" required>
                    </div>
                    <div class="mb-4">
                        <label for="nest_id" class="block mb-2 text-gray-300">Nest ID</label>
                        <input type="number" placeholder="1" id="nest_id" name="nest_id" class="w-full p-2 bg-black border border-zinc-800 text-white rounded" required>
                    </div>
                    <div class="flex justify-end">
                        <button type="button" onclick="toggleModal()" class="bg-red-500 text-white px-4 py-2 rounded mr-2">Cancel</button>
                        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Create</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script>
        function toggleModal() {
            const modal = document.getElementById('createEggModal');
            modal.classList.toggle('hidden');
        }
    </script>
</body>
</html>








    


    <script>
        const sidebarLinks = [{
                title: 'Overview',
                icon: 'fa-desktop',
                url: 'dashboard',
            },
            {
                title: 'Users',
                icon: 'fa-users',
                url: 'users',
            },
            {
                title: 'Products',
                icon: 'fa-box',
                url: 'products',
            },
            {
                title: 'Settings',
                icon: 'fa-gear',
                url: 'settings',
                hasDivider: true,
            },
            {
                title: 'Servers',
                icon: 'fa-server',
                url: 'servers',
            },
            {
            title: 'Images',
            icon: 'fa-egg',
            active: true,
            url: '{{ route('admin.eggs') }}',
        },
        ];

        function generateSidebarLinks() {
            const sidebarLinksContainer = document.getElementById('sidebar-links');
            sidebarLinks.forEach(link => {
                const listItem = document.createElement('li');
                const activeClass = link.active ? 'bg-url' : '';

                listItem.innerHTML = `
            <a href="${link.url}" class="flex items-center p-2 text-gray-900 rounded-lg dark:text-white group transform transition-transform hover:scale-105 ${activeClass}">
                <i class="fa-solid fa-lg text-gray-300 ${link.icon}"></i>
                <span class="flex-1 ms-3 whitespace-nowrap">${link.title}</span>
            </a>
        `;

                sidebarLinksContainer.appendChild(listItem);
                if (link.hasDivider) {
                    const divider = document.createElement('div');
                    divider.classList.add('border-custom');
                    sidebarLinksContainer.appendChild(divider);
                }
            });
        }

        document.addEventListener('DOMContentLoaded', generateSidebarLinks);
    </script>
@endsection
