@extends('admin.layouts.app')

@section('title', 'Settings')

@section('content')
<style>
    .bg-cards {
        background-color: #0f0f11;
        border: 1px solid #1d1d1d;
    }

    .bg-cards-1 {
        background-color: #070707;
        border: 1px solid #1d1d1d;
    }

    .bg-icon {
        background-color: #0f0f11;
        box-shadow: 0px 0px 4px #000;
        border: 1px solid #1d1d1d;
    }

    .border-devider {
        border-color: #1d1d1d;
    }

    .border-bottom-1 {
        border-bottom: 1px solid #1d1d1d;
    }

    .border-global {
        border: 1px solid #1d1d1d;
    }

    .bg-url {
        background-color: #171719;
        border: 1px solid #1d1d1d;
    }

    .w-custom {
        width: fit-content;
    }

    .product-card {
        display: flex;
        align-items: center;
        background-color: #1d1d1d;
        border: 1px solid #1d1d1d;
        border-radius: 8px;
        padding: 8px;
        margin-bottom: 10px;
    }

    .product-image {
        width: 100px;
        height: 100px;
        object-fit: cover;
        border-radius: 8px;
        margin-right: 16px;
    }

    .product-info {
        flex: 1;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .product-name {
        font-size: 16px;
        color: #ffffff;
    }

    .product-price {
        font-size: 16px;
        color: #ffffff;
        font-weight: bold;
    }
</style>

<aside id="logo-sidebar"
    class="fixed top-0 left-0 z-40 w-64 h-screen pt-20 transition-transform -translate-x-full bg-sidebar border-sidebar sm:translate-x-0"
    aria-label="Sidebar">
    <div class="h-full px-3 pb-4 overflow-y-auto bg-sidebar">
        <ul id="sidebar-links" class="space-y-2 font-medium">

        </ul>
    </div>
</aside>

<div class="container bg-cards mb-6">
    <div class="server p-6 rounded-lg shadow-lg">
        <h2 class="text-xl text-gray-300 font-semibold mb-4">Create Product</h2>
        <form action="{{ route('admin.products.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="grid grid-cols-2 gap-4 mb-4">
                <!-- Left column inputs -->
                <div>
                    <div class="flex mb-4">
                        <input type="text" id="title" name="title"
                            class="w-full bg-black text-white border-global p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required placeholder="Enter title">
                    </div>
                    <div class="flex mb-4">
                        <input type="number" id="price" name="price"
                            class="w-full bg-black text-white border-global p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required placeholder="Enter price">
                    </div>
                    <div class="flex mb-4">
                        <input type="number" id="ram" name="ram"
                            class="w-full bg-black text-white border-global p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required placeholder="Amount of RAM in MB">
                    </div>
                    <div class="flex mb-4">
                        <input type="number" id="cpu" name="cpu"
                            class="w-full bg-black text-white border-global p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required placeholder="Amount of CPU in %">
                    </div>
                    <div class="flex mb-4">
                        <input type="number" id="disk" name="disk"
                            class="w-full bg-black text-white border-global p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required placeholder="Amount of Disk in MB">
                    </div>
                </div>

                <!-- Right column inputs -->
                <div>
                    <div class="flex mb-4">
                        <input type="number" id="slots" name="slots"
                            class="w-full bg-black text-white border-global p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required placeholder="Amount of Slots">
                    </div>
                    <div class="flex mb-4">
                        <input type="number" id="databases" name="databases"
                            class="w-full bg-black text-white border-global p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required placeholder="Amount of databases">
                    </div>
                    <div class="flex mb-4">
                        <input type="number" id="backups" name="backups"
                            class="w-full bg-black text-white border-global p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required placeholder="Amount of backups">
                    </div>
                    <div class="flex mb-4">
                        <input type="number" id="ports" name="ports"
                            class="w-full bg-black text-white border-global p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required placeholder="Amount of ports">
                    </div>
                    <div class="flex mb-4">
                        <input type="url" id="image" name="image" required placeholder="Image URL"
                            class="w-full bg-black text-white border-global p-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                </div>
            </div>

            <div class="flex w-full">
                <button type="submit"
                    class="bg-blue-800 text-white rounded font-bold w-full px-4 py-2 hover:bg-blue-500 hover:text-white transition-colors">
                    Create Product
                </button>
            </div>
        </form>
    </div>
</div>

<div class="server p-6 rounded-lg shadow-lg bg-cards">
    <h2 class="text-xl text-gray-300 font-semibold mb-4">Active Products</h2>
    @if($activeProducts->isEmpty())
        <p class="text-gray-400">No products available.</p>
    @else
        <div class="flex flex-wrap gap-4">
            @foreach($activeProducts as $product)
                <div class="flex items-center bg-black p-4 rounded-lg border border-zinc-800 w-full md:w-1/3">
                    <img src="{{ $product->image }}" alt="Product Image" class="w-24 h-24 object-cover rounded-lg mr-4">
                    <div class="flex-1 flex justify-between items-center">
                        <div>
                            <div class="text-gray-300 font-semibold">{{ $product->title }}</div>
                            <div class="text-gray-400">{{ $product->price }}$</div>
                        </div>
                        <form action="{{ route('admin.products.destroy', $product->id) }}" method="POST">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="text-red-500 hover:text-red-700">Delete</button>
                        </form>
                    </div>
                </div>
            @endforeach
        </div>
    @endif
</div>


<script>
    const sidebarLinks = [
        {
            title: 'Overview',
            icon: 'fa-desktop',
            url: '{{ route('admin.dashboard') }}',
        },
        {
            title: 'Users',
            icon: 'fa-users',
            url: '{{ route('admin.users') }}',
        },
        {
            title: 'Products',
            icon: 'fa-box',
            url: 'products',
            active: true,
        },
        {
            title: 'Settings',
            icon: 'fa-gear',
            url: 'settings',
            hasDivider: true,
            active: false,
        },
        {
            title: 'Servers',
            icon: 'fa-server',
            url: '{{ route('admin.servers') }}',
        },
        {
            title: 'Images',
            icon: 'fa-egg',
            url: '{{ route('admin.eggs') }}',
        },
      
    ];

    function generateSidebarLinks() {
        const sidebarLinksContainer = document.getElementById('sidebar-links');
        sidebarLinks.forEach(link => {
            const listItem = document.createElement('li');
            const activeClass = link.active ? 'bg-url' : '';

            listItem.innerHTML = `
            <a href="${link.url}" class="flex items-center p-2 text-gray-900 rounded-lg dark:text-white group transform transition-transform hover:scale-105 ${activeClass}">
                <i class="fa-solid fa-lg text-gray-300 ${link.icon}"></i>
                <span class="flex-1 ms-3 whitespace-nowrap">${link.title}</span>
            </a>
        `;

            sidebarLinksContainer.appendChild(listItem);
            if (link.hasDivider) {
                const divider = document.createElement('div');
                divider.classList.add('border-custom');
                sidebarLinksContainer.appendChild(divider);
            }
        });
    }

    document.addEventListener('DOMContentLoaded', generateSidebarLinks);
</script>
@endsection
