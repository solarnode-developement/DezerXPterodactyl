@extends('layouts.dash')
@php
    $ad = \App\Models\Ad::first();
@endphp
@section('title', 'Market Place')

@section('content')
    <style>
        :root {
            --bg-color-cards: #0c0c0c;
            --border-color-cards: #1d1d1d72;
            --border-color-icon: #1a1a1a;
            --border-color-devider: #1d1d1d;
            --border-color-global: #1d1d1d;
            --bg-color-url: #171717;
        }

        .bg-cards {
            background-color: var(--bg-color-cards);
            border: 1px solid var(--border-color-cards);
        }

        .bg-icon {
            background-color: var(--bg-color-cards);
            border: 1px solid var(--border-color-icon);
        }

        .border-devider {
            border-bottom: 1px solid var(--border-color-devider);
        }

        .border-global {
            border: 1px solid var(--border-color-global);
        }

        .bg-url {
            background-color: var(--bg-color-url);
        }

        .w-custom {
            width: fit-content;
        }
    </style>

    <x-sidebar />

    <div class="grid grid-cols-1 md:grid-cols-3 gap-3">

        @foreach ($products as $product)
            <x-product-card :product="$product" />
        @endforeach

    </div>
    
    <x-footer />



    </script>
    <script>
        const sidebarLinks = [{
                title: 'Overview',
                icon: 'fa-desktop',
                url: '{{ route('dashboard') }}',
                active: false,
            },
            {
                title: 'Deploy Instance',
                icon: 'fa-plus',
                url: 'deploy',
            },
            {
                title: 'Market Place',
                icon: 'fa-shop',
                url: 'shop',
                hasDivider: true,
                active: true,

            },
            {
                title: 'Credits',
                icon: 'fa-coins',
                url: 'credits',
                active: false,

            },
            {
                title: 'Fun',
                icon: 'fa-gun',
                url: 'russian-roulette',
                active: false,

            },
            {
                title: 'Website',
                icon: 'fa-globe',
                url: '{{ $ad->website ?? 'https://dezerx.com' }}',
            },

        ];

        function generateSidebarLinks() {
            const sidebarLinksContainer = document.getElementById('sidebar-links');
            sidebarLinks.forEach(link => {
                const listItem = document.createElement('li');
                const activeClass = link.active ? 'bg-url' : '';

                listItem.innerHTML = `
                <a href="${link.url}" class="flex items-center p-2 text-gray-900 rounded-lg dark:text-white group transform transition-transform hover:scale-105 ${activeClass}">
                    <i class="fa-solid fa-lg text-gray-300 ${link.icon}"></i>
                    <span class="flex-1 ms-3 whitespace-nowrap">${link.title}</span>
                </a>
            `;

                sidebarLinksContainer.appendChild(listItem);
                if (link.hasDivider) {
                    const divider = document.createElement('div');
                    divider.classList.add('border-custom');
                    sidebarLinksContainer.appendChild(divider);
                }
            });
        }

        document.addEventListener('DOMContentLoaded', generateSidebarLinks);
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            @if (session('notification'))
                Swal.fire({
                    icon: "{{ session('notification.icon') }}",
                    title: "{{ session('notification.title') }}",
                    text: "{{ session('notification.text') }}",
                    showConfirmButton: true,
                    confirmButtonText: 'OK'
                });
            @endif
        });
    </script>
@endsection
