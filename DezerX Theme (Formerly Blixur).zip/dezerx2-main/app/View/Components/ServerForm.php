<?php

namespace App\View\Components;

use Illuminate\View\Component;

class ServerForm extends Component
{
    public $locations;

    public function __construct($locations)
    {
        $this->locations = $locations;
    }

    public function render()
    {
        return view('components.server-form');
    }
}
