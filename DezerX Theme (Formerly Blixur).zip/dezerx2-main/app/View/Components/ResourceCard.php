<?php

namespace App\View\Components;

use Illuminate\View\Component;

class ResourceCard extends Component
{
    public $icon;
    public $title;
    public $value;
    public $unit;

    public function __construct($icon, $title, $value, $unit = '')
    {
        $this->icon = $icon;
        $this->title = $title;
        $this->value = $value;
        $this->unit = $unit;
    }

    public function render()
    {
        return view('components.resource-card');
    }
}
