<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Log;

class CreateUserController extends Controller
{
    protected $client;
    protected $apiUrl;
    protected $apiKey;

    public function __construct()
    {
        $this->apiUrl = env('PTERODACTYL_API_URL');
        $this->apiKey = env('PTERODACTYL_API_KEY');

        $this->client = new Client([
            'base_uri' => $this->apiUrl,
            'headers' => [
                'Authorization' => "Bearer {$this->apiKey}",
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
            ],
            'verify' => true,
        ]);
    }
    public function generateUsername($prefix = 'dezer')
    {
        $randomString = substr(str_shuffle('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 8);
        return $prefix . $randomString;
    }

    public function createUser($email, $username)
    {
        $dezeruser = $this->generateUsername();

        try {
            Log::info('Sending request to create user in Pterodactyl', [
                'email' => $email,
                'username' => $username,
            ]);

            $response = $this->client->post('/api/application/users', [
                'json' => [
                    'email' => $email,
                    'username' => $dezeruser,
                    'first_name' => $username,
                    'last_name' => 'Dezer',
                ],
            ]);

            $data = json_decode($response->getBody()->getContents(), true);
            Log::info('Response from Pterodactyl API', [
                'status_code' => $response->getStatusCode(),
                'data' => $data,
            ]);

            if (isset($data['attributes']['id'])) {
                return $data['attributes']['id'];
            }

            return null;

        } catch (\Exception $e) {
            Log::error('Error creating user in Pterodactyl', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return null;
        }
    }
}
