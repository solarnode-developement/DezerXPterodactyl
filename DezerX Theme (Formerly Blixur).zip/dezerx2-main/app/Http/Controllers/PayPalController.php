<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use GuzzleHttp\Client as GuzzleClient;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use GuzzleHttp\Client; // Correct import for Guzzle Client
use GuzzleHttp\Exception\RequestException; // Correct import for RequestException
class PayPalController extends Controller
{
    protected $guzzleClient;

    public function __construct()
    {
        $this->guzzleClient = new GuzzleClient();
    }

    public function index()
    {

        return view('credits');
    }

    public function purchase(Request $request)
    {
        $coinQuantity = $request->input('coin_quantity');
        $pricePerCoin = 0.6;
        $totalAmount = $pricePerCoin * $coinQuantity;
        $token = bin2hex(random_bytes(32));
        DB::table('payment_tokens')->insert([
            'token' => $token,
            'used' => false,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        session([
            'payment_token' => $token,
            'coin_quantity' => $coinQuantity,
        ]);
        $clientId = env('PAYPAL_SANDBOX_CLIENT_ID');
        $clientSecret = env('PAYPAL_SANDBOX_CLIENT_SECRET');
        try {
            $response = $this->guzzleClient->post('https://api-m.sandbox.paypal.com/v1/oauth2/token', [
                'form_params' => [
                    'grant_type' => 'client_credentials',
                ],
                'headers' => [
                    'Authorization' => 'Basic ' . base64_encode("$clientId:$clientSecret"),
                    'Content-Type' => 'application/x-www-form-urlencoded',
                ],
            ]);

            $result = json_decode($response->getBody(), true);
            $accessToken = $result['access_token'];
            $paymentResponse = $this->guzzleClient->post('https://api-m.sandbox.paypal.com/v1/payments/payment', [
                'json' => [
                    'intent' => 'sale',
                    'payer' => [
                        'payment_method' => 'paypal',
                    ],
                    'transactions' => [
                        [
                            'amount' => [
                                'total' => number_format($totalAmount, 2),
                                'currency' => 'USD',
                            ],
                            'description' => 'Purchase of ' . $coinQuantity . ' Coins',
                        ],
                    ],
                    'redirect_urls' => [
                        'return_url' => url('/paypal/success'),
                        'cancel_url' => url('/paypal/cancel'),
                    ],
                ],
                'headers' => [
                    'Authorization' => 'Bearer ' . $accessToken,
                    'Content-Type' => 'application/json',
                ],
            ]);

            $paymentResult = json_decode($paymentResponse->getBody(), true);

            if (isset($paymentResult['links'][1]['href'])) {
                return redirect($paymentResult['links'][1]['href']);
            } else {
                throw new \Exception('Payment approval link not found in response');
            }
        } catch (\Exception $e) {
            Log::error('PayPal payment creation failed', ['error' => $e->getMessage()]);
            return redirect()->back()->withErrors('Payment creation failed.');
        }
    }


    public function success(Request $request)
    {
        $coinQuantity = session('coin_quantity');
        $token = session('payment_token');

        if (!$coinQuantity || !$token) {
            return redirect('/paypal/success')->withErrors('Invalid payment data.');
        }

        $userId = auth()->id();
        $user = DB::table('users')->where('id', $userId)->first();
        $currentCoins = isset($user->credits) ? $user->credits : 0;
        $newCoins = $currentCoins + $coinQuantity;

        // Update the user's credits and mark the payment token as used
        DB::table('users')->where('id', $userId)->update(['credits' => $newCoins]);
        DB::table('payment_tokens')->where('token', $token)->update(['used' => true]);

        // Clear the session variables
        session()->forget(['payment_token', 'coin_quantity']);

        // Flash success notification
        session()->flash('notification', [
            'type' => 'success',
            'icon' => 'success',
            'title' => 'Purchase Completed',
            'text' => 'Your purchase was successful! Your new coin balance is ' . $newCoins,
        ]);

        // Send Discord notification
        $this->sendDiscordSuccessNotification($userId, $coinQuantity, $newCoins);

        return view('credits', [
            'credits' => $newCoins,
        ]);
    }

    protected function sendDiscordSuccessNotification($userId, $coinQuantity, $newCoins)
    {
        $client = new Client();
        $embed = [
            'embeds' => [[
                'title' => '💰 Purchase Successful',
                'color' => 65280,
                'fields' => [
                    [
                        'name' => 'User ID',
                        'value' => $userId,
                        'inline' => true,
                    ],
                    [
                        'name' => 'Coins Added',
                        'value' => $coinQuantity,
                        'inline' => true,
                    ],
                    [
                        'name' => 'New Coin Balance',
                        'value' => $newCoins,
                        'inline' => false,
                    ],
                ],
                'footer' => [
                    'text' => 'Transaction Notification',
                ],
            ]]
        ];

        try {
            $client->post(config('services.webhook.webhook_url'), [
                'json' => $embed,
                'headers' => [
                    'Content-Type' => 'application/json',
                ],
            ]);
        } catch (RequestException $e) {
            Log::error('Discord webhook request failed: ' . $e->getMessage());
        }
    }



    public function cancel(Request $request)
    {
        $token = session('payment_token');

        if ($token) {
            DB::table('payment_tokens')
                ->where('token', $token)
                ->update(['used' => true]);
        }

        session()->forget(['payment_token', 'coin_quantity']);

        session()->flash('notification', [
            'type' => 'error',
            'icon' => 'error',
            'title' => 'Purchase Cancelled',
            'text' => 'The purchase was cancelled or already completed.',
        ]);

        return redirect('/credits');
    }

    public function claimCoupon(Request $request)
    {
        $validated = $request->validate([
            'coupon_name' => 'required|string|exists:coupons,coupon_name',
        ]);

        $coupon = DB::table('coupons')->where('coupon_name', $validated['coupon_name'])->first();

        if (!$coupon) {
            return redirect()->back()->with('error', 'Coupon not found.');
        }

        if ($coupon->uses <= 0) {
            return redirect()->back()->with('error', 'Coupon has already been used up.');
        }

        $user = Auth::user();

        if (!$user) {
            return redirect()->back()->with('error', 'User not authenticated.');
        }

        $alreadyClaimed = DB::table('coupon_claims')
            ->where('coupon_id', $coupon->id)
            ->where('user_id', $user->id)
            ->exists();

        if ($alreadyClaimed) {
            return redirect()->back()->with('error', 'You have already claimed this coupon.');
        }

        DB::table('coupons')
            ->where('coupon_name', $coupon->coupon_name)
            ->update(['uses' => $coupon->uses - 1]);

        if (!is_null($coupon->credits)) {
            $user->credits += $coupon->credits;
        }

        $attributes = ['ram', 'cpu', 'disk', 'ports', 'databases', 'backups', 'slots'];
        foreach ($attributes as $attribute) {
            if (!is_null($coupon->$attribute)) {
                $user->$attribute += $coupon->$attribute;
            }
        }

        $user->save();
        DB::table('coupon_claims')->insert([
            'coupon_id' => $coupon->id,
            'user_id' => $user->id,
            'claimed_at' => now(),
        ]);

        return redirect()->back()->with('success', 'Coupon claimed successfully.');
    }

}
