<?php

namespace App\Http\Controllers\Pterodactyl;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class ConsoleController extends Controller
{

    private function getWebSocketDetails($identifier)
    {
        $url = "{$this->pterodactylApiBase}/api/client/servers/{$identifier}/websocket";
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->pterodactylClientApiKey,
            'Accept' => 'application/json',
        ])->withoutVerifying()->get($url);
        if ($response->successful()) {
            $responseData = $response->json();
            return [
                'url' => $responseData['data']['socket'] ?? null,
                'token' => $responseData['data']['token'] ?? null,
            ];
        } else {
            return null;
        }
    }
    
    


    
    public function showConsole($serverId)
    {
        $webSocketDetails = $this->getWebSocketDetails($serverId);
        $serverDetails = $this->getServerDetails($serverId);
        
        if ($webSocketDetails && $serverDetails) {
            return view('server.console', [
                'websocketToken' => $webSocketDetails['token'],
                'websocketUrl' => $webSocketDetails['url'],
                'serverDetails' => $serverDetails,
            ]);
        } else {
            return abort(500, 'Unable to retrieve WebSocket, server, or client user details.');
        }
    }
}
