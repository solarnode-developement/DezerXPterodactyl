<?php
namespace App\Http\Controllers\Pterodactyl;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class SettingController extends Controller
{

    public function showSettings(Request $request, $identifier)
    {
        $serverDetails = $this->getServerDetails($identifier);

        return view('server.settings', [
            'serverDetails' => $serverDetails,
            'identifier' => $identifier,
        ]);
    }

    public function updateServerDetails(Request $request, $identifier)
    {
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string|max:255',
        ]);
    
        $url = "{$this->pterodactylApiBase}/api/client/servers/{$identifier}/settings/rename";
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->pterodactylClientApiKey,
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ])
          ->post($url, [
              'name' => $validatedData['name'],
              'description' => $validatedData['description'],
          ]);
    
        if ($response->successful()) {
            return redirect()->back()->with('success', 'Server details updated successfully.');
        } else {
            return redirect()->back()->with('error', 'Failed to update server details.');
        }
    }
    
}
