<?php

namespace App\Http\Controllers\Pterodactyl;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use GuzzleHttp\Client;

class FileManagerController extends Controller {


    // Get Directory
    private function getDirectoryContents( $serverId, $directory = '/' ) {
        $url = "{$this->pterodactylApiBase}/api/client/servers/{$serverId}/files/list";
        $response = Http::withHeaders( [
            'Authorization' => 'Bearer ' . $this->pterodactylClientApiKey,
            'Accept' => 'application/json',
        ] )
        ->get( $url, [ 'directory' => $directory ] );

        if ( $response->successful() ) {
            $responseData = $response->json();
            return $responseData[ 'data' ] ?? [];
        } else {
            return null;
        }
    }




    // Get File Content
    public function getFileContents( Request $request, $identifier ) {
        $filePath = $request->input( 'file' );
        $serverDetails = $this->getServerDetails( $identifier );
        if ( empty( $filePath ) ) {
            return response()->json( [ 'error' => 'File path is required' ], 400 );
        }
        $url = "{$this->pterodactylApiBase}/api/client/servers/{$identifier}/files/contents?file=" . urlencode( $filePath );
        $response = Http::withHeaders( [
            'Authorization' => 'Bearer ' . $this->pterodactylClientApiKey,
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ] )
        ->get( $url );
        if ( $response->successful() ) {
            $fileContent = $response->body();
            $decodedContent = json_decode( $fileContent, true );
            if ( json_last_error() === JSON_ERROR_NONE ) {
                if ( is_array( $decodedContent ) ) {
                    $fileContent = json_encode( $decodedContent, JSON_PRETTY_PRINT );
                } elseif ( is_string( $decodedContent ) ) {
                    $fileContent = stripslashes( $decodedContent );
                }
            } else {
                $fileContent = stripslashes( $fileContent );
            }
            return view( 'server.file-content', [
                'fileContent' => $fileContent,
                'identifier' => $identifier,
                'filePath' => $filePath,
                'serverDetails' => $serverDetails,
            ] );
        } else {
            return view( 'server.file-content', [
                'fileContent' => 'Unable to fetch file content.',
                'identifier' => $identifier,
                'filePath' => $filePath,
                'serverDetails' => $serverDetails
            ] );
        }
    }




    // Write File
    public function writeFile( Request $request, $identifier ) {
        $filePath = $request->input( 'file' );
        $fileContent = $request->input( 'content', '' );
        $fileContent = str_replace( [ '\r\n', '\r' ], '\n', $fileContent );
        $fileContent = trim( $fileContent );
        $client = new Client( [
            'verify' => true,
        ] );
        $url = "{$this->pterodactylApiBase}/api/client/servers/{$identifier}/files/write?file=" . urlencode( $filePath );
        try {
            $response = $client->request( 'POST', $url, [
                'headers' => [
                    'Authorization' => 'Bearer ' . $this->pterodactylClientApiKey,
                    'Accept' => 'application/json',
                    'Content-Type' => 'text/plain',
                ],
                'body' => $fileContent,
            ] );
            return redirect()->back()->with( 'status', 'File saved successfully!' );
        } catch ( \Exception $e ) {
            return redirect()->back()->withErrors( 'Failed to write file: ' . $e->getMessage() );
        }
    }




    // Show Files Function
    public function showFiles( Request $request, $identifier ) {
        $currentDirectory = $request->input( 'directory', '/' );
        $serverDetails = $this->getServerDetails( $identifier );
        $directoryContents = $this->getDirectoryContents( $identifier, $currentDirectory );

        return view( 'server.file-manager', [
            'serverDetails' => $serverDetails,
            'directoryContents' => $directoryContents,
            'currentDirectory' => $currentDirectory,
            'identifier' => $identifier,
        ] );
    }




    // Upload Files Function
    public function uploadFiles(Request $request, $identifier) {
        $server = $this->getServerDetails($identifier);
        $pteroUrl = $this->pterodactylApiBase;
        $pteroApiKey = $this->pterodactylClientApiKey;
        $currentDirectory = $request->input('directory', '');
        $request->validate([
            'file' => 'required|file',
        ]);
        $file = $request->file('file');
        $backendDirectory = $currentDirectory ? trim($currentDirectory, '/') : '';
        try {
            $response = Http::withHeaders([
                'Authorization' => "Bearer {$pteroApiKey}",
                'Accept' => 'application/json',
            ])
            ->get("{$pteroUrl}/api/client/servers/{$identifier}/files/upload");
    
            if ($response->successful()) {
                $responseData = $response->json();
                $attributes = data_get($responseData, 'attributes', []);
                $uploadUrl = data_get($attributes, 'url');
                $queryParams = [];
                parse_str(parse_url($uploadUrl, PHP_URL_QUERY), $queryParams);
                $token = $queryParams['token'] ?? '';
    
                if ($uploadUrl && $token) {
                    $uploadUrlWithDirectory = $uploadUrl . (parse_url($uploadUrl, PHP_URL_QUERY) ? '&' : '?') . http_build_query(['directory' => $backendDirectory]);
                    $uploadResponse = Http::withHeaders([
                        'Authorization' => "Bearer {$token}",
                    ])
                    ->attach(
                        'files', file_get_contents($file->getRealPath()), $file->getClientOriginalName()
                    )->post($uploadUrlWithDirectory);
    
                    if ($uploadResponse->successful()) {
                        return redirect()->back()->with('status', 'File uploaded successfully!');
                    } else {
                        return redirect()->back()->withErrors('Failed to upload file.');
                    }
                } else {
                    return redirect()->back()->withErrors('Failed to retrieve upload URL or token.');
                }
            } else {
                return redirect()->back()->withErrors('Failed to retrieve upload URL.');
            }
        } catch (\Exception $e) {
            return redirect()->back()->withErrors('Failed to upload file due to an exception.');
        }
    }
    




    // Delete Files
    public function deleteFile(Request $request, $identifier) {
        $root = $request->input('root', '/');
        $files = $request->input('files', []);
    
        if (empty($files)) {
            return redirect()->back()->withErrors(['error' => 'No files specified for deletion']);
        }
    
        $url = "{$this->pterodactylApiBase}/api/client/servers/{$identifier}/files/delete";
        $data = [
            'root' => $root,
            'files' => $files,
        ];
    
        try {
            $response = Http::withHeaders([
                    'Authorization' => 'Bearer ' . $this->pterodactylClientApiKey,
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json',
                ])
                ->post($url, $data); 
    
            if ($response->successful()) {
                return redirect()->back()->with('status', 'File(s) deleted successfully!');
            } else {
                return redirect()->back()->withErrors('Failed to delete file(s).');
            }
        } catch (\Exception $e) {
            return redirect()->back()->withErrors('Failed to delete file(s) due to an exception: ' . $e->getMessage());
        }
    }
    



    
    // Create Folder
    public function createFolder(Request $request, $identifier) {
        $root = $request->input('root', '/');
        $folderName = $request->input('folder_name');
    
        if (empty($folderName)) {
            return redirect()->back()->withErrors(['error' => 'Folder name is required']);
        }
    
        $url = "{$this->pterodactylApiBase}/api/client/servers/{$identifier}/files/create-folder";
        $data = [
            'root' => $root,
            'name' => $folderName,
        ];
    
        try {
            $response = Http::withHeaders([
                    'Authorization' => 'Bearer ' . $this->pterodactylClientApiKey,
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json',
                ])
                ->post($url, $data);  
    
            if ($response->successful()) {
                return redirect()->back()->with('status', 'Folder created successfully!');
            } else {
                return redirect()->back()->withErrors('Failed to create folder.');
            }
        } catch (\Exception $e) {
            return redirect()->back()->withErrors('Failed to create folder due to an exception: ' . $e->getMessage());
        }
    }
    

}
