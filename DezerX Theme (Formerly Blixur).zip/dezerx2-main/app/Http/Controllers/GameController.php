<?php
namespace App\Http\Controllers;

use Auth;
use Illuminate\Http\Request;

class GameController extends Controller
{
    public function showRoulette()
    {
        return view('roulette');
    }

    public function playRoulette(Request $request)
    {
        $user = Auth::user();
        $bet = $request->input('bet');
        $choice = $request->input('color');
    
        if ($user->credits < $bet) {
            return back()->with('error', 'Not enough credits!');
        }
    
        sleep(3);
    
        $outcome = (rand(1, 100) <= 10) ? 'red' : 'black';
    
        if ($outcome === $choice) {
            $user->credits += $bet;
            $message = "You chose $choice and won! The outcome was $outcome. You doubled your bet!";
        } else {
            $user->credits -= $bet;
            $message = "You chose $choice and lost. The outcome was $outcome. Better luck next time.";
        }
    
        $user->save();
    
        return back()->with('message', $message)->with('credits', $user->credits);
    }
    
}
