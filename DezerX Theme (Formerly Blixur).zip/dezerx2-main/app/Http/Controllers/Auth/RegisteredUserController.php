<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use Illuminate\Validation\Rules;
use Illuminate\View\View;
use App\Http\Controllers\CreateUserController;
use Illuminate\Validation\ValidationException;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
class RegisteredUserController extends Controller
{
    protected $webhookUrl;

    public function __construct()
    {
        $this->webhookUrl = config('services.webhook.webhook_url'); // Add this to your config
    }

    /**
     * Display the registration view.
     */
    public function create(): View
    {
        return view('auth.register');
    }

    /**
     * Handle an incoming registration request.
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request): RedirectResponse
    {
        $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'lowercase', 'email', 'max:255', 'unique:' . User::class],
            'password' => ['required', 'confirmed', Rules\Password::defaults()],
            'cf-turnstile-response' => ['required', 'string'],
        ]);

        $this->validateTurnstile($request);

        // Fetch default resources
        $resources = \DB::table('default_resources')->pluck('value', 'key')->toArray();
        Log::info('Fetched default resources:', $resources);

        $ram = $resources['ram'] ?? 1024;
        $cpu = $resources['cpu'] ?? 100;
        $disk = $resources['disk'] ?? 2048;
        $slots = $resources['slots'] ?? 1;
        $databases = $resources['databases'] ?? 1;
        $ports = $resources['ports'] ?? 1;
        $backups = $resources['backups'] ?? 1;

        Log::info('Allocated resources for new user:', [
            'ram' => $ram,
            'cpu' => $cpu,
            'disk' => $disk,
            'slots' => $slots,
            'databases' => $databases,
            'ports' => $ports,
            'backups' => $backups,
        ]);

        // Convert name to lowercase
        $name = strtolower($request->name);
        $name = str_replace(' ', '', $name);

        $user = User::create([
            'name' => $name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'ram' => $ram,
            'cpu' => $cpu,
            'disk' => $disk,
            'slots' => $slots,
            'databases' => $databases,
            'ports' => $ports,
            'backups' => $backups,
        ]);

        // Check if this is the first user and update the role if needed
        if (User::count() === 1) {
            $user->update(['role' => 'admin']);
        }

        $pterodactylController = new CreateUserController();
        $pterodactylUserId = $pterodactylController->createUser(
            $request->email,
            $name
        );

        if ($pterodactylUserId) {
            $user->pterodactyl_user_id = $pterodactylUserId;
            $user->save();
        }

        event(new Registered($user));
        Auth::login($user);

        // Send a Discord webhook notification
        $this->sendDiscordNotification($user);

        return redirect()->route('dashboard');
    }

    /**
     * Send Discord notification upon user registration.
     *
     * @param \App\Models\User $user
     * @return void
     */
protected function sendDiscordNotification(User $user)
{
    $client = new Client();

    // Prepare the embed message
    $embed = [
        'embeds' => [[
            'title' => '🎉 New User Registration',
            'color' => 7506394, // Optional: a color for the embed
            'fields' => [
                [
                    'name' => 'Name',
                    'value' => $user->name,
                    'inline' => true,
                ],
                [
                    'name' => 'Email',
                    'value' => $user->email,
                    'inline' => true,
                ],
                [
                    'name' => 'Role',
                    'value' => $user->role ?? 'user',
                    'inline' => true,
                ],
                [
                    'name' => 'Registered At',
                    'value' => now()->toDateTimeString(),
                    'inline' => true,
                ],
            ],
            'footer' => [
                'text' => 'User Registration System',
            ],
        ]]
    ];

    try {
        $client->post($this->webhookUrl, [
            'json' => $embed,
            'headers' => [
                'Content-Type' => 'application/json',
            ],
        ]);
    } catch (RequestException $e) {
        Log::error('Discord webhook request failed: ' . $e->getMessage());
    }
}


    /**
     * Validate Turnstile CAPTCHA.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return void
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    protected function validateTurnstile(Request $request)
    {
        $response = Http::asForm()->post('https://challenges.cloudflare.com/turnstile/v0/siteverify', [
            'secret' => config('services.turnstile.secret_key'),
            'response' => $request->input('cf-turnstile-response'),
            'remoteip' => $request->ip(),
        ]);

        $captchaData = $response->json();

        if (!$captchaData['success']) {
            throw ValidationException::withMessages([
                'cf-turnstile-response' => ['CAPTCHA verification failed. Please try again.'],
            ]);
        }
    }
}
