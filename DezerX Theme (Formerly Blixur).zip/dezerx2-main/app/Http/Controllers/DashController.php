<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class DashController extends Controller
{
    public function index()
    {
        $servers = $this->fetchServersForUser();
        foreach ($servers as &$server) {
            $server['ip_and_port'] = $this->getServerIpAndPort($server);
            $resources = $this->fetchServerResources($server['attributes']['identifier']);
            
            if (isset($resources['attributes']['current_state'])) {
                Log::info("Server {$server['attributes']['identifier']} current_state: " . $resources['attributes']['current_state']);
                $server['state'] = $resources['attributes']['current_state'];
            } else {
                $server['state'] = 'Not Available';
                Log::info("Server {$server['attributes']['identifier']} does not have a current_state attribute.");
            }
        }
    
        $renewal_cost = DB::table('default_resources')
            ->where('key', 'renewal_cost')
            ->value('value');
    
        return view('dashboard', [
            'servers' => $servers,
            'renewal_cost' => $renewal_cost,
        ]);
    }
    
    
    
    

    private function fetchServersForUser()
    {
        $user = Auth::user();
        if (!$user) {
            return [];
        }

        $pterodactylId = $user->pterodactyl_user_id;
        $url = env('PTERODACTYL_API_URL') . '/api/application/servers?include=allocations';
        $apiKey = env('PTERODACTYL_API_KEY');

        $response = Http::withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $apiKey,
        ])->withOptions([
            'verify' => true,
        ])->get($url);

        if ($response->successful()) {
            $servers = $response->json()['data'];
            return array_filter($servers, function ($server) use ($pterodactylId) {
                return $server['attributes']['user'] == $pterodactylId;
            });
        } else {
            return [];
        }
    }

    private function fetchServerResources($identifier)
    {
        $url = env('PTERODACTYL_API_URL') . "/api/client/servers/{$identifier}/resources";
        $clientKey = env('PTERODACTYL_CLIENT_KEY');

        $response = Http::withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $clientKey,
        ])->withOptions([
            'verify' => true,
        ])->get($url);

        if ($response->successful()) {
            return $response->json();
        } else {
            return [];
        }
    }

    private function getServerIpAndPort($server)
    {
        $allocations = $server['attributes']['relationships']['allocations']['data'] ?? [];
        $ipAndPort = [];

        foreach ($allocations as $allocation) {
            $ip = $allocation['attributes']['ip'] ?? 'N/A';
            $port = $allocation['attributes']['port'] ?? 'N/A';
            $ipAndPort[] = $ip . ':' . $port;
        }

        return implode(', ', $ipAndPort) ?: 'unknown';
    }
}
