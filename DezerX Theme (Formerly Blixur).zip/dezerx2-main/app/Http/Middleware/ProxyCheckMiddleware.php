<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use Illuminate\Support\Facades\Log;

class ProxyCheckMiddleware
{
    protected $webhookUrl;

    public function __construct()
    {
        $this->webhookUrl = config('services.webhook.webhook_url'); // Ensure this is set in your config
    }

    public function handle(Request $request, Closure $next)
    {
        $client = new Client();
        $ip = $request->ip();
        $apiKey = config('services.proxycheck.key');

        try {
            $response = $client->get("http://proxycheck.io/v2/{$ip}?key={$apiKey}&vpn=1&risk=1");
            $result = json_decode($response->getBody(), true);

            if (isset($result[$ip]) && $result[$ip]['proxy'] === 'yes') {
                $this->sendDiscordNotification($ip, $request); // Pass the request to the notification
                return response()->view('errors.403', [], 403);
            }
        } catch (RequestException $e) {
            Log::error('ProxyCheck API request failed: ' . $e->getMessage());
        }

        return $next($request);
    }

    protected function sendDiscordNotification($ip, Request $request)
    {
        $client = new Client();

        $timestamp = now()->toDateTimeString();
        $userAgent = $request->header('User-Agent');
        $embed = [
            'embeds' => [[
                'title' => '🚫 Access Denied',
                'color' => 16711680,
                'fields' => [
                    [
                        'name' => 'IP',
                        'value' => "||{$ip}||",
                        'inline' => true,
                    ],
                    [
                        'name' => 'Timestamp',
                        'value' => $timestamp,
                        'inline' => true,
                    ],
                    [
                        'name' => 'User-Agent',
                        'value' => $userAgent,
                        'inline' => false,
                    ],
                    [
                        'name' => 'Request URL',
                        'value' => $request->fullUrl(),
                        'inline' => false,
                    ],
                ],
                'footer' => [
                    'text' => 'VPN/Proxy Detection System',
                ],
            ]]
        ];

        try {
            $client->post($this->webhookUrl, [
                'json' => $embed,
                'headers' => [
                    'Content-Type' => 'application/json',
                ],
            ]);
        } catch (RequestException $e) {
            Log::error('Discord webhook request failed: ' . $e->getMessage());
        }
    }

}
