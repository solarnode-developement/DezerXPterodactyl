<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;

class BillUsers extends Command
{
    protected $signature = 'billing:hourly';
    protected $description = 'Bill users for server usage';

    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        $this->info('Billing process started');

        $defaultResources = DB::table('default_resources')->pluck('value', 'key');
        $renewalCost = $defaultResources->get('renewal_cost', 0); 
        if ($renewalCost == 0) {
            $this->info('Renewal cost is 0. Billing is disabled.');
            return; 
        }
        $servers = DB::table('servers')
            ->select('id', 'user_id', 'owner_id')
            ->whereNotNull('created_at')
            ->get();
        
        foreach ($servers as $server) {
            $user = DB::table('users')->where('id', $server->user_id)->first();
            Log::info("Processing server ID {$server->id} with owner ID {$server->owner_id}");

            if ($user) {
                $billingAmount = $renewalCost; 

                if ($user->credits >= $billingAmount) {
                    DB::table('users')->where('id', $user->id)->update([
                        'credits' => $user->credits - $billingAmount
                    ]);
                    Log::info("User {$user->id} billed \${$billingAmount} for server {$server->id}");
                } else {
                    Log::warning("User {$user->id} does not have enough credits to be billed for server {$server->id}");
                    $response = Http::withHeaders([
                        'Accept' => 'application/json',
                        'Content-Type' => 'application/json',
                        'Authorization' => 'Bearer ' . env('PTERODACTYL_API_KEY'),
                    ])->post(env('PTERODACTYL_API_URL') . "/api/application/servers/{$server->owner_id}/suspend");

                    if ($response->successful()) {
                        Log::info("Server {$server->id} suspended successfully.");
                    } else {
                        Log::error("Failed to suspend server {$server->id}. Response: " . $response->body());
                    }
                }
            } else {
                Log::error("User with ID {$server->user_id} not found for server {$server->id}");
            }
        }
        $this->info('Billing process completed');
    }
}
