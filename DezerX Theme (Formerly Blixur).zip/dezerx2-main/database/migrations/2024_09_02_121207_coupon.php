<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('coupons', function (Blueprint $table) {
            $table->id();
            $table->string('coupon_name')->unique();
            $table->integer('uses')->nullable();
            $table->timestamps();
            
            // Optional fields, all nullable
            $table->integer('credits')->nullable();
            $table->integer('ram')->nullable();
            $table->integer('cpu')->nullable();
            $table->integer('disk')->nullable();
            $table->integer('slots')->nullable();
            $table->integer('databases')->nullable();
            $table->integer('ports')->nullable();
            $table->integer('backups')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        //
    }
};
