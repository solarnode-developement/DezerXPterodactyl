<?php

use App\Http\Controllers\Admin\OverviewController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\EggsController;
use App\Http\Controllers\Providers\DiscordController;
use App\Http\Controllers\DashController;
use App\Http\Controllers\GameController;
use App\Http\Controllers\MarketPlaceController;
use App\Http\Controllers\PayPalController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\Pterodactyl\AllocationController;
use App\Http\Controllers\Pterodactyl\BackupController;
use App\Http\Controllers\Pterodactyl\ConsoleController;
use App\Http\Controllers\Pterodactyl\DatabaseController;
use App\Http\Controllers\Pterodactyl\DeployController;
use App\Http\Controllers\Pterodactyl\FileManagerController;
use App\Http\Controllers\Pterodactyl\PluginManagerController;
use App\Http\Controllers\Pterodactyl\SettingController;
use App\Http\Controllers\StripeController;
use App\Http\Middleware\AdminController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

Route::get('/403', function () {
    return response()->view('errors.403', [], 403);
})->name('403');

// authentication via discord
Route::get('auth/discord/redirect', [DiscordController::class, 'redirect'])->name('discord.redirect');
Route::get('auth/discord/callback', [DiscordController::class, 'callback'])->name('discord.callback');

// dashboard routes
Route::get('/dashboard', [DashController::class, 'index'])->middleware(['auth', 'verified'])->name('dashboard');

// Fetch eggs and deploy logic
Route::get('/api/eggs/{nestId}', [DeployController::class, 'fetchEggs']);
Route::get('/deploy', [DeployController::class, 'index'])->name('deploy.index');
Route::post('/deploy/create-server', [DeployController::class, 'createServer'])->name('create-server');
Route::get('/api/eggs/{nestId}', [DeployController::class, 'fetchEggs']);
Route::post('/create-server', [DeployController::class, 'createServer'])->name('create-server-post');

// market place
Route::get('/shop', [MarketPlaceController::class, 'index'])->middleware(['auth', 'verified'])->name('shop');
Route::post('/purchase/{id}', [MarketPlaceController::class, 'purchase'])->name('purchase');

//coupons
Route::post('/claim-coupon', [PayPalController::class, 'claimCoupon'])->name('claim.coupon');

// roulette
Route::get('/russian-roulette', [GameController::class, 'showRoulette'])->name('russian-roulette.show');
Route::post('/russian-roulette/play', [GameController::class, 'playRoulette'])->name('russian-roulette.play');

// credit purchase
Route::get('/credits', [PayPalController::class, 'index'])->name('coins.index')->middleware(['auth', 'verified']);
Route::post('/credits/purchase', [PayPalController::class, 'purchase'])->name('coins.purchase')->middleware(['auth', 'verified']);
Route::get('/paypal/success', [PayPalController::class, 'success'])->name('paypal.success')->middleware(['auth', 'verified']);
Route::get('/paypal/cancel', [PayPalController::class, 'cancel'])->name('paypal.cancel')->middleware(['auth', 'verified']);
Route::post('stripe/coins', [StripeController::class, 'purchase'])->name('stripe.purchase')->middleware(['auth', 'verified']);
Route::get('stripe/success', [StripeController::class, 'success'])->name('stripe.success')->middleware(['auth', 'verified']);
Route::get('stripe/cancel', [StripeController::class, 'cancel'])->name('stripe.cancel')->middleware(['auth', 'verified']);

// admin routes
Route::middleware(['auth', 'verified', AdminController::class . ':admin'])->group(function () {
    Route::get(uri: '/admin/dashboard', action: [OverviewController::class, 'index'])->name('admin.dashboard');


    Route::get(uri: '/admin/eggs', action: [EggsController::class, 'index'])->name('admin.eggs');
    Route::put('/admin/egg/{id}', [EggsController::class, 'update'])->name('admin.eggs.update');
    Route::delete('/admin/egg/{id}', [EggsController::class, 'destroy'])->name('admin.eggs.destroy');
    Route::post('/admin/eggs/create', [EggsController::class, 'store'])->name('admin.eggs.store');

    Route::get('/admin/servers', [OverviewController::class, 'servers'])->name('admin.servers');
    Route::get('/admin/settings', [OverviewController::class, 'settings'])->name('admin.settings');
    Route::post('/filter-servers', [OverviewController::class, 'filterServers'])->name('filter.servers');
    Route::get('/admin/users', [OverviewController::class, 'users'])->name('admin.users');
    Route::delete('/admin/users/{id}', [OverviewController::class, 'deleteUsers'])
        ->name('admin.user.delete');
        Route::put('/admin/users/{id}/update-credits', [OverviewController::class, 'updateCredits'])->name('admin.user.updateCredits');
        Route::post('/admin/dashboard/update', [OverviewController::class, 'updateDefaultResources'])
        ->name('update.default.resources');
    Route::post('/store-location', [OverviewController::class, 'store'])->name('store.location');
    Route::post('/store-ads', [OverviewController::class, 'ads'])->name('store.ads');
    Route::post('/store-coupons', [OverviewController::class, 'coupons'])->name('store.coupons');
    Route::delete('/admin/users/{id}', [OverviewController::class, 'deleteUser'])->name('admin.user.delete');
    Route::get('/admin/products', [ProductController::class, 'create'])
        ->name('admin.packages.store');
    Route::get('/admin/products/create', [ProductController::class, 'create'])->name('admin.products.create');
    Route::post('/admin/products', [ProductController::class, 'store'])->name('admin.products.store');
    Route::delete('/admin/products/{id}', [ProductController::class, 'destroy'])->name('admin.products.destroy');

});

// server side

Route::group(['prefix' => 'server/{identifier}', 'middleware' => 'check.server.owner'], function () {
    Route::get('/console', [ConsoleController::class, 'showConsole'])->name('server.console');
    Route::get('/backups', [BackupController::class, 'showBackups'])->name('server.p.backups');
    Route::get('/database', [DatabaseController::class, 'index'])->name('server.backups');
    Route::post('/create-backup', [BackupController::class, 'createBackup'])->name('backup.create');
    Route::post('/create-database', [DatabaseController::class, 'createDatabase'])->name('database.create');
    Route::delete('/backups/{backupUuid}', [BackupController::class, 'deleteBackup'])->name('backup.delete');
    Route::get('/backups/{backupUuid}/download', [BackupController::class, 'downloadBackup'])->name('backup.download');
    Route::get('/settings', [SettingController::class, 'showSettings'])->name('server.settings');
    Route::post('/update', [SettingController::class, 'updateServerDetails'])->name('server.update');
    Route::get('/plugins', [PluginManagerController::class, 'showPlugins'])->name('server.plugins');
    Route::get('/search-plugins', [PluginManagerController::class, 'searchPlugins'])->name('search.plugins');
    Route::post('/plugin/{pluginId}/download', [PluginManagerController::class, 'downloadPlugin'])->name('plugin.download');
    Route::get('/network', [AllocationController::class, 'showNetwork'])->name('server.network');
    Route::get('/file-manager', [FileManagerController::class, 'showFiles'])->name('server.files');
    Route::get('/file-content', [FileManagerController::class, 'getFileContents'])->name('server.file-content');
    Route::post('/files/write', [FileManagerController::class, 'writeFile'])->name('files.write');
    Route::post('/upload', [FileManagerController::class, 'uploadFiles'])->name('server.upload');
    Route::post('/files/delete', [FileManagerController::class, 'deleteFile'])->name('server.delete-file');
    Route::post('/create-folder', [FileManagerController::class, 'createFolder'])->name('server.create-folder');


});


require __DIR__ . '/auth.php';
